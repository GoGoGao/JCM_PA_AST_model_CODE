cat target_ref/ref.fa GCF_000174395.2.fa > ref.fa
