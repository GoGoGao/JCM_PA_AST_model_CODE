#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Cwd qw(abs_path);
use Getopt::Long;
use File::Basename;
use lib "$Bin/lib/";
use PATHWAY;

###============ 默认参数设置 =============
my %opt=(sample_set_n=>"100",outdir=>".",shdir=>"./Shell",db_search=>"CARD",step=>123,vf=>"2G",splitn=>1,
    db_cardopt=>" -word_size 27 -evalue 1e-5 -num_threads 2 -outfmt 0 -num_alignments 10000 ",
    db_vfopt=>" -evalue 1e-5  -num_threads 2 -outfmt \"6 qseqid qlen sseqid slen pident length mismatch gapopen qstart qend sstart send evalue bitscore\"",
    filter_cardopt=> " ",
    filter_vfopt=>"--identity 90 --align_len 18"
);
GetOptions(\%opt,"sample_set_n:i","mNGSread","WGSread","data_list:s","pathogen:s","list_readsTaxAnno:s","list_DetectTaxon:s","step:i","vf:s","splitn:i","outdir:s","shdir:s","db_search:s","db_cardopt:s","db_vfopt:s","filter_cardopt:s","filter_vfopt:s","notrun","locate","qopts:s","help","PE");

###============ 程序、数据库设置 =============
#保留毒力基因检测接口
my $db_vf = "";
my $db_vf_anno = "";
my $blastx = "";

###数据库
my $db_CARD = "$Bin/lib/card_db/card.nucl"; #耐药数据库参考基因
my $db_card_anno = "$Bin/lib/card_db/card.info.xls"; #耐药数据库参考基因注释信息
my $db_pathogen = "$Bin/lib/target_pathogens/ref.fa";
###软件
my $blastn = "$Bin/lib/ncbi-blast-2.9.0+/bin/blastn";
my $minimap2 = "$Bin/lib/minimap2-2.17_x64-linux/minimap2";
###任务调度
my $super_worker = "perl $Bin/lib/super_worker.pl --cyqt 1 --maxjob 200 --sleept 30";
###序列分析、注释
my $convert_fq2fa = "perl $Bin/lib/convert_fq2fa.pl";
my $split_fa = "perl $Bin/lib/split_fa.pl";
my $format_convert = "perl $Bin/lib/format_convert.pl";
my $m6_filter2anno = "perl $Bin/lib/m6_filter2anno.pl";
my $stat_ARGdetect = "perl $Bin/lib/stat_ARGdetect.pl";
my $stat_ARGdetect_filter = "perl $Bin/lib/stat_ARGdetect_filter.pl";
my $strain_ARGdetect = "perl $Bin/lib/strain_ARGdetect.pl";
my $predict_arg2spe = "perl $Bin/lib/predict_arg2spe.pl";
my $cover_depth = "perl $Bin/lib/cover_depth.pl";
my $patho_ARGdetect = "perl $Bin/lib/patho_ARGdetect.pl";
my $predict_AST = "perl $Bin/lib/predict_AST.pl";
$opt{mNGSread} && ($predict_AST .= " --mNGSread");
$opt{WGSread} && ($predict_AST .= " --WGSread");

###================ help information ==========================
($opt{data_list} && -s $opt{data_list})|| die "Name: $0
Description: Blast reads to ARG database for detecting ARG and predict AST on key ARGs screened from ARG-BGWAS(Lasso regression method).
Version: 1.0,20210307 by hanpeng,chengfangyuan,gaojianpeng
Contact: p.han\@genskey.com,jp.gao\@genskey.com,fy.chen\@genskey.com
Usage: perl $0 --data_list Pathogen.reads.list --list_readsTaxAnno reads.taxanno.list --list_DetectTaxon detect.taxon.list [options]
Options:
  *--data_list		 [file]  list file of clean data as input, must be set. format: samplename\\tpathogen_reads1.fq.gz or samplename\\tpathogen_reads1.fq.gz\\tpathogen_reads2.fq.gz
  --sample_set_n	 [num]	 set the sample set size splited by \\n\\n
  --mNGSread			 if set, it means to predict the AST for mNGS by read-based ARG test
  --WGSread			 if set, it means to predict the AST for WGS by read-based ARG test
  --list_readsTaxAnno 	 [file]  set the list file for each sample's reads taxon annotaion
  --list_DetectTaxon	 [file]  set the list file for each sample's detected species
  --pathogen		 [str]	 when WGS or focus the pathogen, can set the pathogen name directly
  --PE                           if set, it means PE sequence data.

[options for database]
  --db_search       	 [str]   set databases which will be searched, default = CARD
  --db_cardopt       	 [str]   set parameters for batst to CARD
  --db_vfopt        	 [str]   set parameters for batst to VFDB
  --filter_cardopt	 [str]   set parameters to filter the blast result of CARD, default not set
  --filter_vfopt         [str]   set parameters to filter the blast result of VFDB, default is '--identity 90 --align_len 18'

[options for running]
  --qopts                [str]   other qsub options 
  --vf                   [str]   resource for qsub, default is 2G
  --notrun                       just produce shell script, not qsub 
  --locate                       run locate, not qsub  
  --help                         output help information
                        
[other options]
  --outdir               [str]   output directory, default is ./
  --shdir                [str]   output shell directory, default is ./Shell
  --splitn               [num]   the number of the divided seq file, defult is 1
  --step    		 [str]   default is 123
                     	     	     step1: fq2fa
	                   	     step2: blast to ref database
                      		     step3: detected ARG stat and predict AST 

Example: 
   perl $0 --data_list Dataclean.total.list --list_readsTaxAnno reads.taxanno.list --list_DetectTaxon detect.taxon.list
   perl $0 --data_list Dataclean.total.list --pathogen \"Klebsiella pneumoniae\" \n";
$opt{help} && die `pod2text $0`;

#========== 目录、文件路径/SGE调度参数设置 ========
#$opt{qopts} ||= " --qopts=' -V ' ";
for ($opt{outdir},$opt{shdir}){-d $_ || `mkdir -p $_`;$_ = abs_path($_);}
$opt{data_list} = abs_path($opt{data_list});
$opt{qopts} && ($super_worker .= " --qopts '$opt{qopts}' ");
$super_worker .= " --dvf 8G ";
#$opt{qc_stat} && ($opt{qc_stat} = abs_path($opt{qc_stat}));

###================= main function =================================
#样本的病原检测结果表单文件，以及样本的reads物种注释文件
my (%readstaxf,%bsdf);
if($opt{list_readsTaxAnno}){
    open IN,$opt{list_readsTaxAnno} || die $!;
    while(<IN>){
	s/^\s+//;s/\s+$//;
        my @ll = split /\s+/;
	$readstaxf{$ll[0]} = $ll[1];
    }
    close IN;
}
if($opt{list_DetectTaxon}){
    open IN,$opt{list_DetectTaxon} || die $!;
    while(<IN>){
        s/^\s+//;s/\s+$//;
        my @ll = split /\s+/;
        $bsdf{$ll[0]} = $ll[1];
    }
    close IN;
}

###主过程
my ($locate_run,$qsub_run);
my $splits = '\n\n';
##step1, convert fq into fa and split it into muti-file
my (@sample,%falist);
(-s "$opt{outdir}/01.Fa_cut") || system("mkdir -p $opt{outdir}/01.Fa_cut");
if ($opt{data_list} && $opt{step}=~/1/){
    my @line=`less $opt{data_list}`;
    my $sh_step1;
    my $i;
    foreach my $line (@line){
        chomp $line;
	$i++;
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
        my @tmp = split /\s+/,$line;
        my $sample = $tmp[0];
        push @sample, $sample;
        my @read = @tmp[1..$#tmp];
        (-s "$opt{outdir}/01.Fa_cut/$sample") || system ("mkdir -p $opt{outdir}/01.Fa_cut/$sample");
        if($opt{PE}){
            $sh_step1 .= "cd $opt{outdir}/01.Fa_cut/$sample\n$convert_fq2fa $read[0] $sample\_1.fa 1\n$split_fa n $opt{splitn} $sample\_1.fa $sample\_1\n$convert_fq2fa $read[1] $sample\_2.fa 2\n$split_fa n $opt{splitn} $sample\_2.fa $sample\_2\n\n";
	}else{
	    $sh_step1 .= "cd $opt{outdir}/01.Fa_cut/$sample\n$convert_fq2fa $read[0] $sample.fa 1\n$split_fa n $opt{splitn} $sample.fa $sample\n";
	    $sh_step1 .= "rm -rf $sample.fa\n";
	}
        for my $nn (1..$opt{splitn}){
	    if($opt{PE}){
                push @{$falist{$sample}},"$opt{outdir}/01.Fa_cut/$sample/$sample\_1\_$nn.fa";
                push @{$falist{$sample}},"$opt{outdir}/01.Fa_cut/$sample/$sample\_2\_$nn.fa";
	    }else{
		push @{$falist{$sample}},"$opt{outdir}/01.Fa_cut/$sample/$sample\_$nn.fa";
	    }
        }
	$i % $opt{sample_set_n} == 0 && ($sh_step1 .= "\n"); #投递任务时，用作分割文件
    }
    & write_file("$opt{shdir}/step1.convert_fq2fa.sh",$sh_step1);
    $locate_run .="$super_worker --mutil --maxjob 20 --splits \"$splits\" step1.convert_fq2fa.sh\n";
    $qsub_run .= "$super_worker step1.convert_fq2fa.sh --resource $opt{vf} --prefix convert_fq2fa --splits '$splits'\n";
}

## step2, blast reads to the ARG databaes
my (%blastout_list,%db);
my @dbs  = split( "-", $opt{db_search} ) if $opt{db_search};for (@dbs){$db{$_}=1;}
if($opt{step}=~/2/){
    my $sh_step2;
    foreach my $db (@dbs){
        my $i = 0;
        for my $sample (@sample) {
	    (-s "$opt{outdir}/02.Blast/$db/$sample") || `mkdir -p $opt{outdir}/02.Blast/$db/$sample`;
            foreach my $tmp (@{$falist{$sample}}){
		$i++;
                chomp $tmp;
                my ($split_fa,$path,$suffix) = fileparse($tmp,qr{.fa});
		my $ref_db = $db eq "CARD" ? $db_CARD : $db eq "VFDB" ? $db_vf : ();
		my $bsoft = $db eq "CARD" ? $blastn : $blastx;
		my $bopts = $db eq "CARD" ? $opt{db_cardopt} : $db eq "VFDB" ? $opt{db_vfopt} : ();
                $sh_step2 .= "$bsoft -query $tmp -db $ref_db $bopts -out $opt{outdir}/02.Blast/$db/$sample/$split_fa.fa.m0\n";
		$sh_step2 .= "$format_convert $opt{outdir}/02.Blast/$db/$sample/$sample\_1.fa.m0 $opt{outdir}/02.Blast/$db/$sample/$sample\_1.fa.m6\n";
		$sh_step2 .= "$minimap2 -x sr -a -t 8 --secondary=no -L $db_pathogen $tmp > $opt{outdir}/02.Blast/$db/$sample/$split_fa.pathogen.sam\n";
		$sh_step2 .= "$cover_depth $opt{outdir}/02.Blast/$db/$sample/$sample\_1.pathogen.sam --prefix $opt{outdir}/02.Blast/$db/$sample/$sample\n";
		#$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 8 -R '\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Files/refgenome -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.0005 -c 1 -OutFolder .\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl $sample.genome.vcf > $sample.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann NC_002516.2 $sample.filter.vcf > $sample.anno.vcf\n"; #变异分析
	#	$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 8 -R '\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Files/refgenome_bwaindex/GCF_000006765.1_ASM676v1_genomic.fna  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Files/refgenome -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.0005 -c 1 -OutFolder .\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl $sample.genome.vcf > $sample.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann NC_002516.2 $sample.filter.vcf > $sample.anno.PAO1.vcf\n";
		###$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 8 -R '\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/FRD1/NZ_CP010555.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.FRD1.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.FRD1.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.FRD1.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/FRD1 -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.0005 -c 1 -OutFolder FRD1\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl FRD1/$sample.FRD1.genome.vcf > $sample.filter.FRD1.vcf\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann NZ_CP054472.1 $sample.filter.vcf > $sample.vcf.anno.FRD1.vcf\n"; #变异分析
		$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n#/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 8 -R '\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/FRD1/NZ_CP010555.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.FRD1.bam\n#/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.FRD1.bam\n#/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.FRD1.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/FRD1 -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.0005 -c 1 -OutFolder FRD1\n#perl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl FRD1/$sample.FRD1.genome.vcf > $sample.filter.FRD1.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann FRD1 $sample.filter.FRD1.vcf > $sample.vcf.anno.FRD1.vcf\n"; #变异分析
	#	$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 16 -R '\''\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'\'' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/F23197/NZ_CP008856.2.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.F23197.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.F23197.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.F23197.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/F23197 -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.00000000000001 -c 1 -OutFolder F23197\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl F23197/$sample.F23197.genome.vcf > $sample.F23197.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann F23197 $sample.F23197.filter.vcf > $sample.F23197.vcf.anno.vcf\n";
	#	$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 16 -R '\''\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'\'' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/ATCC_27853/NZ_CP101912.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.ATCC_27853.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.ATCC_27853.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.ATCC_27853.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/ATCC_27853 -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.00000000000001 -c 1 -OutFolder ATCC_27853\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl ATCC_27853/$sample.ATCC_27853.genome.vcf > $sample.ATCC_27853.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann ATCC_27853 $sample.ATCC_27853.filter.vcf > $sample.ATCC_27853.vcf.anno.vcf\n";
		#$sh_step2 .="cd $opt{outdir}/02.Blast/$db/$sample/\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 16 -R '\''\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'\'' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/LESB58/FM209186.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.LESB58.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.LESB58.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.LESB58.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/LESB58/ -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.00000000000001 -c 1 -OutFolder LESB58\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl LESB58/$sample.LESB58.genome.vcf > $sample.LESB58.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann LESB58 $sample.LESB58.filter.vcf > $sample.LESB58.vcf.anno.vcf\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 16 -R '\''\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'\'' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/MTB-1/CP006853.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.MTB-1.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.MTB-1.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.MTB-1.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/MTB-1/ -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.00000000000001 -c 1 -OutFolder MTB-1\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl MTB-1/$sample.MTB-1.genome.vcf > $sample.MTB-1.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann MTB-1 $sample.MTB-1.filter.vcf > $sample.MTB-1.vcf.anno.vcf\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 16 -R '\''\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'\'' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/PA-VAP-4/CP028368.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.PA-VAP-4.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.PA-VAP-4.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.PA-VAP-4.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/PA-VAP-4/ -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.00000000000001 -c 1 -OutFolder PA-VAP-4\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl PA-VAP-4/$sample.PA-VAP-4.genome.vcf > $sample.PA-VAP-4.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann PA-VAP-4 $sample.PA-VAP-4.filter.vcf > $sample.PA-VAP-4.vcf.anno.vcf\n/data/Yixue/gaojianpeng/BTK/Software/Mapping/bwa/bwa mem -Y -t 16 -R '\''\@RG\\tID:$sample\\tPL:$sample\\tSM:$sample'\'' /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/UCBPP-PA14/CP000438.1.fa  $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa | /data/Yixue/gaojianpeng/BTK/Software/Tools/samtools sort --threads 16 -o $sample.UCBPP-PA14.bam\n/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools index $sample.UCBPP-PA14.bam\n/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet20230227/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.UCBPP-PA14.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV3/Input_Files/RefGenomes/UCBPP-PA14/ -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.00000000000001 -c 1 -OutFolder UCBPP-PA14\nperl /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/filter.vcf.pl UCBPP-PA14/$sample.UCBPP-PA14.genome.vcf > $sample.UCBPP-PA14.filter.vcf\nset java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann UCBPP-PA14 $sample.UCBPP-PA14.filter.vcf > $sample.UCBPP-PA14.vcf.anno.vcf\n";
		$sh_step2 .= "rm -rf $opt{outdir}/01.Fa_cut/$sample/$sample\_1.fa $opt{outdir}/02.Blast/$db/$sample/$sample\_1.fa.m0 $opt{outdir}/02.Blast/$db/$sample/$split_fa.pathogen.sam\n";
		$i % $opt{sample_set_n} == 0 && ($sh_step2 .= "\n");
                push @{$blastout_list{$db}{$sample}}, "$opt{outdir}/02.Blast/$db/$sample/$split_fa.fa.m0";
            }
        }
#	$i % 5 != 0 && ($sh_step2 .= "\n");
    }
    & write_file("$opt{shdir}/step2.blast_$opt{db_search}.sh",$sh_step2);
    $locate_run .= "$super_worker --mutil --maxjob 20 --splits \"$splits\" step2.blast_$opt{db_search}.sh\n";
    $qsub_run .= "$super_worker step2.blast_$opt{db_search}.sh --resource $opt{vf} --prefix $opt{db_search} --splits '$splits' \n";
}

## step3: filter m6file, annotation and obtain profile
if($opt{step}=~/3/){
    my $sh_step3;
    for my $d(sort keys %db){
	my $i=0;
	my $list_anno;
	for my $sample (@sample){
	    (-s "$opt{outdir}/03.Arg2AST/$d/$sample") || system("mkdir -p $opt{outdir}/03.Arg2AST/$d/$sample");
	    $i++;
	    $sh_step3 .= "cd $opt{outdir}/03.Arg2AST/$d/$sample\n";
            my $filteropts = $d eq "CARD" ? $opt{filter_cardopt} : $d eq "VFDB" ? $opt{filter_vfopt} : ();
            my $annoinfo = $d eq "CARD" ? $db_card_anno : $d eq "VFDB" ? $db_vf_anno : ();
	    $sh_step3 .= "$m6_filter2anno $opt{outdir}/02.Blast/$d/$sample/$sample\_1.fa.m6 $sample.m6.filter.anno $filteropts\n";
	    $sh_step3 .= "$stat_ARGdetect $sample.m6.filter.anno $sample.stat.xls $sample.reads.anno.lca $sample.reads.anno.lca.exact 2> arg_stat.log\n";
	    $sh_step3 .= "$stat_ARGdetect_filter $sample.stat.xls > $sample.stat.filter.xls\n";
	    $opt{list_readsTaxAnno} && ($sh_step3 .= "$predict_arg2spe $sample.reads.anno.lca $readstaxf{$sample} > $sample.arg2taxon.xls\n");
	    ##基因的物种归属预测
	    $sh_step3 .= "$patho_ARGdetect $sample.stat.filter.xls $opt{outdir}/02.Blast/$d/$sample/$sample\.cvgstat  --vcf $opt{outdir}/02.Blast/$d/$sample/$sample.anno.vcf ";
	    $opt{list_DetectTaxon} && ($sh_step3 .= " --detect_patho $bsdf{$sample}");
	    $opt{list_readsTaxAnno} && ($sh_step3 .= " --arg2taxon $sample.arg2taxon.xls");
	    $opt{pathogen} && ($sh_step3 .= " --pathogen \"$opt{pathogen}\"");
	    $sh_step3 .= " > $sample.DrugClass_detectARGs.xls 2> arg_locate.log\n";
	    ##基因检出及药敏预测
	    $sh_step3 .= "$predict_AST $sample.DrugClass_detectARGs.xls > $sample.predict.xls\n";

#	    $sh_step3 .= "\n";
	    $i % $opt{sample_set_n} == 0 && ($sh_step3 .= "\n");
	    $list_anno .= "$sample\t$opt{outdir}/03.Arg2AST/$d/$sample/$sample.stat.xls\n";
        }
	& write_file("$opt{outdir}/03.Arg2AST/$d/$d.anno.list",$list_anno);
    }
    & write_file("$opt{shdir}/step3.1.Arg2AST.sh",$sh_step3);
    $locate_run .= "sh step3.1.Arg2AST.sh\n";
    $qsub_run .= "$super_worker step3.1.Arg2AST.sh --resource $opt{vf} --prefix arganno --splits '\\n\\n' \n";
}

# writeshell and run
$opt{locate} ? & write_file("$opt{shdir}/run_ARG_predict.sh","cd $opt{shdir}\n$locate_run\n") : & write_file("$opt{shdir}/run_ARG_predict.sh","cd $opt{shdir}\n$qsub_run\n");
$opt{notrun} || (system"cd $opt{shdir};sh run_ARG_predict.sh");

###=========sub function========
sub write_file(){
    my ($file,$content) = @_;
    open OUT,">$file" || die $!;
    print OUT $content;
    close OUT;
}
