#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Getopt::Long;
my %opt=();
GetOptions(\%opt,"pathogen:s","detect_patho:s","arg2taxon:s","focus_species:s","patho_argCN:s","feature_weight:s");

@ARGV == 2 || die "perl $0 <arg.detect> <coverage.stat> --detect_patho <patho.detect> --arg2taxon <predict_arg2taxon> >drug_detect.xls\n";

#====== 数据库及参数设置 =======
#my $arg_anno_db = "$Bin/MEGARes2.1/megares_v2.1.2.info.xls";
$opt{focus_species} ||= "$Bin/report_db/focus_patho.list";
$opt{patho_argCN} ||= "$Bin/report_db/patho_ARG.CN.xls";
$opt{feature_weight} ||= "$Bin/report_db/feature_weight.xls";

#=============================== main function ===============================
open IN,$opt{feature_weight} || die $!;
my %key_gf;
while(<IN>){
    /^#/ && next;
    my @ll = split /\t/;
    $key_gf{$ll[4]} = 1;
}
close IN;

##ARG的物种归属预测
my %arg_taxon;
if($opt{arg2taxon}){
    open IN,$opt{arg2taxon} || die $!;
    while(<IN>){
        chomp;
        /^#/ && next;
        my @ll = split /\t/;
	$arg_taxon{$ll[0]} = "$ll[2]\t$ll[4]";
    }
    close IN;
}

###物种基因拷贝数
my %spe_max_argCN;
if($opt{patho_argCN}){
    open IN,$opt{patho_argCN} || die $!;
    while(<IN>){
	chomp;
	my @ll = split /\t/;
	$spe_max_argCN{$ll[0]}{$ll[7]} = (split /,/,$ll[3])[1];
    }
    close IN;
}

##关注的报告病原菌范围
open IN,$opt{focus_species} || die $!;
my (%focus_spe,%spe_rn,%spe_cov,%spe_covxdepth);
while(<IN>){
    chomp;
    s/^\s+//;s/\s+$//;
    $focus_spe{$_} = 1;
    $spe_rn{$_} ||= 1;  #先默认设置为1
#    $spe_cov{$_} ||= 0.000001;
    $spe_covxdepth{$_} ||= 0.000001;
}
close IN;

###病原检出统计
my ($arg_detectf,$patho_detectf) = @ARGV;
open IN,$patho_detectf || die $!;
my (%spe2genus_cov_rn,%total_bac_rn);
while(<IN>){
    chomp;
    my @ll = split /\t/;
    $spe_rn{$ll[0]} = $ll[2];
    $spe_covxdepth{$ll[0]} = ($ll[5]*$ll[4])/100;
    $spe2genus_cov_rn{$ll[0]} = "$ll[4]\t$ll[5]\t$ll[2]\tNA";
    $total_bac_rn{"Bacteria"} = "NA";
}
close IN;

if($opt{detect_patho} && -s $opt{detect_patho}){
    open IN,$opt{detect_patho} || die $!;
    my %uniq = ();
    $total_bac_rn{"Bacteria"} = 0;
    my ($bac_rn_index,$genusName_index,$genus_rn_index,$speName_index,$spe_rn_index,$cov_index,$depth_index);
    my $h = <IN>;chomp $h;
    my @hh = split /\t/,$h;
    for my $i(0..$#hh){
        $hh[$i] eq "Kingdom" && ($bac_rn_index = $i);
        $hh[$i] eq "Genus拉丁名" && ($genusName_index = $i);
        $hh[$i] eq "属原始reads数" && ($genus_rn_index = $i);
        $hh[$i] eq "种拉丁名" && ($speName_index = $i);
        $hh[$i] eq "种原始reads数" && ($spe_rn_index = $i);
        $hh[$i] eq "Coverage(ratio)" && ($cov_index = $i);
        $hh[$i] eq "Depth" && ($depth_index = $i);
    }
    while(<IN>){
        chomp;
        my @ll = split /\t/;
        $ll[$cov_index] eq "-" && next;
        my $cov = (split /\(/,$ll[$cov_index])[0];$cov =~ s/\%//;
        my $depth = $ll[$depth_index];
        if($focus_spe{$ll[$speName_index]}){
	    $spe_rn{$ll[$speName_index]} = $ll[$spe_rn_index]; #物种实际检出reads数
	    $spe_covxdepth{$ll[$speName_index]} = ($cov*$depth)/100; #用作后边计算ARG的拷贝数
	    $spe2genus_cov_rn{$ll[$speName_index]} = "$cov\t$depth\t$ll[$spe_rn_index]\t$ll[$genus_rn_index]"; #覆盖度、覆盖深度、种reads数、属reads数
        }
        $ll[$genusName_index] eq "-" && ($ll[$genusName_index] = $ll[$speName_index]); #属名称
        $uniq{$ll[$genusName_index]}++;
        $uniq{$ll[$genusName_index]} < 2 && ($total_bac_rn{$ll[$bac_rn_index]}+=$ll[$genus_rn_index]); #细菌总reads数
    }
    close IN;
}

###耐药基因检出
open IN,$arg_detectf || die $!;
my (%Patho_args,%is_locate,%not_locate);
my @focus_patho_sort = sort {$spe_rn{$b} <=> $spe_rn{$a}} keys %focus_spe;
while(<IN>){
    chomp;
    /^#/ && next;
    my @ll = split /\t/;
    my ($arg_taxons,$arg_born) = @ll[20,22];
    my @predict_spe;
    $arg_taxon{$ll[4]} && (@predict_spe = split /\t/,$arg_taxon{$ll[4]});
#$ll[4] eq  "SHV beta-lactamase" && (print STDERR "@predict_spe\n");
    my ($locate_mark,$cycle) = (0,1);
    CY:{;}
    for my $spe(@focus_patho_sort){
	$spe_covxdepth{$spe} == 0.000001 && next;
	my $arg_copy_n = sprintf "%.2f",($ll[16]*$ll[17])/$spe_covxdepth{$spe};
	$arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
	$spe_max_argCN{$spe}{$ll[6]} ||= 3;
	$cycle == 1 && (print STDERR "$ll[6]\t$arg_copy_n\t$spe\t$spe_max_argCN{$spe}{$ll[6]}+3\tCycle$cycle\n");
	$cycle > 1 && (print STDERR "$ll[6]\t$arg_copy_n\t$spe\t$spe_max_argCN{$spe}{$ll[6]}+3\tCycle$cycle\n");
	$cycle >= 50 && ($arg_copy_n = 1);
	($arg_copy_n >= $spe_max_argCN{$spe}{$ll[6]}+3 || $arg_copy_n <= 0.5) && next; #基因copy数一般不超过20,且不能小于0.4
	my $focus_genus = (split /\s+/,$spe)[0]; #第一种是直接数据库记录或预测的arg来源物种与关注物种匹配，第二种是数据库记录或预测的arg来源物种所在属和关注的物种genus水平相同，第三种是数据库记录或预测的基因归属物种与关注物种不一致，此时看耐药是否存在质粒介导方式
	if($arg_taxons =~ /$spe/ig || $arg_taxons =~ /$focus_genus/ig ){
	    $Patho_args{$spe} .= "$spe\tDB_taxon_anno\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n\t$ll[19]\t$ll[18]\n";
	    $is_locate{"$ll[4]\t$ll[6]"} = 1;
	    $locate_mark = 1;
	}
    }
    if($locate_mark == 0 && $arg_born =~ /plasmid/){
        for my $spe(@focus_patho_sort){
	    $spe_covxdepth{$spe} == 0.000001 && next;
            my $arg_copy_n = sprintf "%.2f",($ll[16]*$ll[17])/$spe_covxdepth{$spe};
            $arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
            $spe_max_argCN{$spe}{$ll[6]} ||= 3;
	    $cycle >= 50 && ($arg_copy_n = 1);
	    ($arg_copy_n >= $spe_max_argCN{$spe}{$ll[6]}+3 || $arg_copy_n <= 0.4) && next; #基因copy数一般不超过20,且不能小于0.4
	    $Patho_args{$spe} .= "$spe\tplasmid\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n\t$ll[19]\t$ll[18]\n";
            $is_locate{"$ll[4]\t$ll[6]"} = 1;
	    $locate_mark = 1;
        }
    }
    if($locate_mark == 0 && $arg_taxon{$ll[4]}){
        for my $spe(@focus_patho_sort){
            $spe_covxdepth{$spe} == 0.000001 && next;
            my $arg_copy_n = sprintf "%.2f",($ll[16]*$ll[17])/$spe_covxdepth{$spe};
            $arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
            $spe_max_argCN{$spe}{$ll[6]} ||= 3;
            $cycle >= 50 && ($arg_copy_n = 1);
            ($arg_copy_n >= $spe_max_argCN{$spe}{$ll[6]}+3 || $arg_copy_n <= 0.5) && next; #基因copy数一般不超过20,且不能小于0.1
            my $focus_genus = (split /\s+/,$spe)[0]; #第一种是直接数据库记录或预测的arg来源物种与关注物种匹配，第二种是数据库记录或预测的arg来源物种所在属和关注的物种genus水平相同，第三种是数据库记录或预测的基因归属物种与关>注物种不一致，此时看耐药是否存在质粒介导方式
	    if($predict_spe[1] =~ /$spe/ig || $predict_spe[0] =~ /$focus_genus/ig){
		$Patho_args{$spe} .= "$spe\tread_taxon_anno\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n\t$ll[19]\t$ll[18]\n";
	        $is_locate{"$ll[4]\t$ll[6]"} = 1;
	        $locate_mark = 1;
	    }
        }
    }

    my $mark = $key_gf{$ll[4]} ? "Key" : "Non_key";
    if(!$is_locate{"$ll[4]\t$ll[6]"} && $cycle < 50){
	print STDERR "#$ll[4]\t$ll[6]\t$mark\tnot_locate\n";
	if($key_gf{$ll[4]}){$cycle++;goto (CY);}
#	$cycle++;goto (CY);
    }else{
	print STDERR "#$ll[4]\t$ll[6]\t$mark\tlocate\n";
    }
    print STDERR "\n";
}
close IN;

###output
print "#focus_patho\tmethod\tdetect_gf\tgf_rn\tdetect_gt\tgt_rn(specific|ARG-like)\tcopy_num\tmodel_type\tVaration\tgenome_coverage(%)\tAvgDepth\tspe_rn\tgenus_rn\ttotal_Bac_rn\n";
for my $spe(sort keys %Patho_args){
    $opt{pathogen} && $opt{pathogen} ne $spe && next;
    my @lines = split /\n/,$Patho_args{$spe};
    for my $line(@lines){
	print "$line\t$spe2genus_cov_rn{$spe}\t$total_bac_rn{Bacteria}\n";
    }
}

