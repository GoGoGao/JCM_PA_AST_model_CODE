#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Getopt::Long;
my ($out_gf_score,$WGSread,$mNGSread,$ppv_cutoff,$min_rn);
GetOptions("out_gf_score"=>\$out_gf_score,"WGSread"=>\$WGSread,"mNGSread"=>\$mNGSread,"ppv_cutoff:i"=>\$ppv_cutoff,"min_rn:i"=>\$min_rn);
$ppv_cutoff ||= 0.9;
$min_rn ||= 10;
@ARGV || die "Usage: perl $0 <patho_ARG.detect> > predict.xls
Version: 3.0,20220103
Contact: p.han\@genskey.com\n\n";

#============ 文件配置 ===========
my $report = $mNGSread ? "$Bin/report_db/focus_patho_drug.report_mNGSread" : ($WGSread ? "$Bin/report_db/focus_patho_drug.report_WGSread" : "$Bin/report_db/focus_patho_drug.report_WGScontig");
#my $feature_weight = "$Bin/report_db/feature_weight.xls";
#my $feature_weight="/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Analyse/paper_v1.1/Tables/03.key_feature/key_feature.xls";
my $feature_weight="/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/LiubingWenzhang/06Tables/key_feature.xls";
my $key_gt_error = "$Bin/report_db/key_gt_error.list";
my $ARG_ppv = "$Bin/report_db/ARG_ppv.stat";
my $gt_similarity = "$Bin/card_db/pairGene.similarity.anno2.xls";
#my $drug_class_db = "$Bin/report_db/drug_class.xls";

##
open IN,$key_gt_error || die $!;
my %keygt_error;
while(<IN>){
    /^#/ && next;
    chomp;
    my @ll = split /\t/;
    $keygt_error{$ll[0]}{$ll[1]}{$ll[3]} = $ll[2];
}
close IN;

##
open IN,$ARG_ppv;
my (%ARG_ppv,%ARG_ppv_freq,%nonkey_gt);
while(<IN>){
    chomp;
    my @ll = split /\t/;
    $ll[5] eq "0/0" && next;
    my $freq = (split /\//,$ll[5])[1];
    $ll[4] ||= 0.001;
    $ARG_ppv{$ll[0]}{$ll[1]}{$ll[3]} = $ll[4];
    $ARG_ppv_freq{$ll[0]}{$ll[1]}{$ll[3]} = (split /\//,$ll[5])[1];
    $freq >= 10 && $ll[4] < 0.6 && ($nonkey_gt{$ll[0]}{$ll[1]}{$ll[2]}{$ll[3]} = 1);
}
close IN;

##
open SI,$gt_similarity;
my (%gt_sim);
while(<SI>){
    /^ARG1_gf/ && next;
    chomp;
    my @ll = split /\t/;
    $gt_sim{$ll[1]}{$ll[3]} ||= $ll[5];
    $gt_sim{$ll[1]}{$ll[3]} =  $gt_sim{$ll[1]}{$ll[3]} >= $ll[5] ? $gt_sim{$ll[1]}{$ll[3]} : $ll[5];
    $gt_sim{$ll[3]}{$ll[1]} = $gt_sim{$ll[1]}{$ll[3]};
}
close SI;

#===== 关键基因及其权重系数 ======
open IN,$feature_weight || die $!;
my (%arg_weight,%argfamily_weight,%gf_keygt);
while(<IN>){
    chomp;
    /^#/ && next;
    my @ll = split /\t/;
	$ll[0]=~s/--/:/g;
	$ll[0]=~s/_/ /g;
	$ll[0]=~s/-/ /g;
    $arg_weight{"Pseudomonas aeruginosa"}{$ll[0]}{$ll[1]} = $ll[2];
	next if $ll[1]=~/\(/;
    $argfamily_weight{"Pseudomonas aeruginosa"}{$ll[0]}{$ll[1]} = $ll[2];
    $gf_keygt{"Pseudomonas aeruginosa"}{$ll[1]}{"xxx"}{"xxx"} = 1;
}
close IN;

my %keyarg=(
	'ampD'=>1,
	'ampR'=>1,
	'ftsI'=>1,
	'gyrA'=>1,
	"gyrB"=>1,
#	"Pseudomonas aeruginosa gyrA conferring resistance to fluoroquinolones"=>1,
#	'Pseudomonas aeruginosa gyrB conferring resistance to fluoroquinolones'=>1,
	'mexA'=>1,
	'mexB'=>1,
	'mexF'=>1,
	'mexR'=>1,
	'nalD'=>1,
	'oprN'=>1,
	'parR'=>1,
	'ParS'=>1
);
#============ main function ==============
my $pathogen_args = shift @ARGV;
open IN,$pathogen_args || die $!;
my (%patho_ARGdetect,%model_type,%patho_cov,%patho_rn,%arg2family,%uniq,%allgene,%first);
while(<IN>){
    chomp;
    /^#/ && next;
    my @ll = split /\t/;
    $patho_cov{$ll[0]} = $ll[9];  #以检出的基因组覆盖度，作为评价数据量的指标
    $patho_rn{$ll[0]} = $ll[11];
    $arg2family{$ll[4]} = $ll[2];
    $allgene{$ll[4]} = 1;
    #if($ll[7]=~/variant/){
	if($ll[4] eq "Pseudomonas aeruginosa gyrA conferring resistance to fluoroquinolones"){
		$ll[4]="gyrA";
	}
	if($ll[4] eq "Pseudomonas aeruginosa gyrB conferring resistance to fluoroquinolones"){
		$ll[4]="gyrB";
	}
	if($keyarg{$ll[4]}){
		$ll[7]='protein variant model';
	}
    if($ll[7] ne "protein homolog model"){
	if($ll[8]){
	    my @aa = split /,/,$ll[8];
	    for my $v(@aa){
	#	my @bb = split /\|/,$v;
#		my $pos_nucl = (split /\(/,$bb[0])[0];
#		my $v0 = $bb[0];$v0 =~ s/\)$//;$v0 .= ")";
		my $var_nucl = $v;
#		print $var_nucl,"\n";
		$uniq{$var_nucl}++;
		$uniq{$var_nucl} == 1 && (push @{$patho_ARGdetect{$ll[0]}},$var_nucl); #
		$model_type{$var_nucl} = "variant";
		
		###
       #         my $var_pro;
       #         if($bb[3] eq "X"){
       #             $bb[4] eq "Synonymous" && next;
       #             my $pos_pro = int($pos_nucl/3);$pos_nucl % 3 > 0 && ($pos_pro += 1);
       #             if($bb[4] eq "Start_nonsyn" || $bb[4] eq "Premature_stop"){
       #                 $var_pro = "$ll[4]:HIGH";
       #             }else{
	#		$bb[6] =~ s/\)$//;
    #                    $var_pro = "$ll[4]:$pos_pro($bb[6])";
    #                }
    #            }else{
    #                if($bb[4] eq "Frame_shift"){$var_pro = "$ll[4]:HIGH";}
    #            }
 #               if($var_pro){$uniq{$var_pro}++;$uniq{$var_pro}==1 && (push @{$patho_ARGdetect{$ll[0]}},$var_pro);$model_type{$var_pro} = "variant";}
            }
	}
    }else{
		next if  $first{$ll[2]} && $first{$ll[2]} == 1;
		push @{$patho_ARGdetect{$ll[0]}},$ll[4];
		$first{$ll[2]}=1;
    }
}
close IN;
#if($patho_cov{"Pseudomonas aeruginosa"} && $patho_cov{"Pseudomonas aeruginosa"} > 50){
#    if(!$allgene{PA_oprD}){
#	push @{$patho_ARGdetect{"Pseudomonas aeruginosa"}},"PA_oprD:HIGH";
#	$model_type{"PA_oprD:HIGH"} = "variant";
#    }
#}

###针对关注的病原菌-药物，预测表型
open IN,$report || die $!;
my (%uniq_ARG_family,%uniq_gf);
my $header = $out_gf_score ? "#Patho\tdrug\tdetect_ARGs\tscores\tcutoff\tpredict\taccuracy\tpatho_rn\tpatho_coverage\tgf_scores\n" : "#Patho\tdrug\tdetect_ARGs\tscores\tcutoff\tpredict\taccuracy\tpatho_rn\tpatho_coverage\n";
print $header;
while(<IN>){
    chomp;
    my @ll = split /\t/;
    my $index = $mNGSread ? 10 : ($WGSread ? 6 : 2);
    $ll[$index] eq "-" && next;  #比较关注的药物，但目前未进行训练
    my ($report_args,$scores,$scores_gf) = ("",0,0); #
    if($patho_cov{$ll[0]}){
	my ($report_args,$scores,$scores_gf) = ("",0,0); #
	for my $arg(@{$patho_ARGdetect{$ll[0]}}){
		#print STDERR  $ll[0],"\t",$ll[1],"\t",$arg,"\n";
		#print $arg,"\n";
	    if($model_type{$arg} && $model_type{$arg} eq "variant"){ #变异模型
			#print STDERR $_,"\t", $arg,"\n";
		if($arg_weight{$ll[0]}{$ll[1]}{$arg} && $arg_weight{$ll[0]}{$ll[1]}{$arg} > 0){
		#	print STDERR $_,"\t", $arg,"\tselect\n";
		    $report_args .= "$arg;";
		    $scores += $arg_weight{$ll[0]}{$ll[1]}{$arg};
		}
	    }elsif($argfamily_weight{$ll[0]}{$ll[1]}{$arg2family{$arg}}){
			#print $arg,"\n";
			$report_args .= "$arg2family{$arg};";
			$scores += $argfamily_weight{$ll[0]}{$ll[1]}{$arg2family{$arg}};
		}else{
		my $arg_family = $arg2family{$arg};
		$arg_weight{$ll[0]}{$ll[1]}{$arg} ||= 0;
		$argfamily_weight{$ll[0]}{$ll[1]}{$arg_family} ||= 0;  #有可能检出一些新的训练集里没有的基因家族，暂不考虑
		$argfamily_weight{$ll[0]}{$ll[1]}{$arg_family} <= 0 && next;
		$uniq_gf{$ll[0]}{$ll[1]}{$arg_family}++;
		if($uniq_gf{$ll[0]}{$ll[1]}{$arg_family}==1){$scores_gf += $argfamily_weight{$ll[0]}{$ll[1]}{$arg_family};}
		if($arg_weight{$ll[0]}{$ll[1]}{$arg} > 0){
                    $uniq_ARG_family{$ll[0]}{$ll[1]}{$arg_family}++;
                    $report_args .= "$arg;";
                    $scores += $arg_weight{$ll[0]}{$ll[1]}{$arg};
                    my @tmp_args = split /;/,$report_args;
                    my ($add,$report_args_tmp) = (0,"");
                    for my $aa(@tmp_args){
                        $aa eq $arg_family && ($add = 1);
                        $aa ne $arg_family && ($report_args_tmp .= "$aa;");
                    }
                    $report_args = $report_args_tmp;
                    $add && ($scores -= $argfamily_weight{$ll[0]}{$ll[1]}{$arg_family});
                }else{
		    if($patho_cov{$ll[0]} >= 95){
			!$keygt_error{$ll[0]}{$ll[1]}{$arg} && $ARG_ppv_freq{$ll[0]}{$ll[1]}{$arg} && $ARG_ppv_freq{$ll[0]}{$ll[1]}{$arg} >= 10 && $ARG_ppv{$ll[0]}{$ll[1]}{$arg} < 0.6 && next;
		    }
		    my $threhold = 0.95;
		    if($ll[0] eq "Acinetobacter baumannii" && $arg_family =~ /^ADC/){$threhold = 0.98351;}
			next unless $gf_keygt{$ll[0]}{$ll[1]}{$arg_family};
		    my @keygt = sort keys %{$gf_keygt{$ll[0]}{$ll[1]}{$arg_family}};
                    my ($high_sim_key,$arg_weight) = (0,0);
                    for my $gt(@keygt){
                        if($gt_sim{$gt}{$arg} && $gt_sim{$gt}{$arg} > $threhold){
                            $high_sim_key ||= $gt_sim{$gt}{$arg}; #
                            $arg_weight ||= "$gt\t$arg_weight{$ll[0]}{$ll[1]}{$gt}"; #
                            $high_sim_key < $gt_sim{$gt}{$arg} && ($arg_weight = "$gt\t$arg_weight{$ll[0]}{$ll[1]}{$gt}");
                        }
                    }

                    my @nonkey_gt = sort keys %{$nonkey_gt{$ll[0]}{$ll[1]}{$arg_family}};
                    my $high_sim_nonkey;
                    for my $gt(@nonkey_gt){
                        if($gt_sim{$gt}{$arg} && $gt_sim{$gt}{$arg} > $threhold){
                            $high_sim_nonkey ||= $gt_sim{$gt}{$arg}; #
                            $high_sim_nonkey < $gt_sim{$gt}{$arg} && ($high_sim_nonkey = $gt_sim{$gt}{$arg});
                        }
                    }

                    if($high_sim_key){ #gt与筛选出来的重要gt具有较高的序列相似性，往往功能上也具有相似性
                        my ($keygt,$keygt_weight) = (split /\t/,$arg_weight)[0,1];
                        my @tmp_args = split /;/,$report_args;
                        my $add = 0;
                        for my $aa(@tmp_args){$aa eq $keygt && ($add = 1);}
                        if(!$add){
                            $uniq_ARG_family{$ll[0]}{$ll[1]}{$arg_family}++;
                            if($uniq_ARG_family{$ll[0]}{$ll[1]}{$arg_family} == 1){
                                $report_args .= "$arg_family;";
                                $scores += $argfamily_weight{$ll[0]}{$ll[1]}{$arg_family};
                            }
                        }
                    }else{
                        $high_sim_nonkey && next;
                        $uniq_ARG_family{$ll[0]}{$ll[1]}{$arg_family}++;
                        if($uniq_ARG_family{$ll[0]}{$ll[1]}{$arg_family} == 1){
                            $report_args .= "$arg_family;";
                            $scores += $argfamily_weight{$ll[0]}{$ll[1]}{$arg_family};
                        }
                    }
		}
	    }
	}
        $scores = sprintf "%.6f", $scores;
        $scores_gf = sprintf "%.6f", $scores_gf;
	$report_args ||= "ND";
        $report_args =~ s/;$//;
	$patho_cov{$ll[0]} eq "-" && ($patho_cov{$ll[0]} = 1);

	my $cutoff_R = $mNGSread ? $ll[10] : ($WGSread ? $ll[6] : $ll[2]);
	$cutoff_R = sprintf "%.6f", $cutoff_R;
	my $drug_ppv = $mNGSread ? ($ll[11] ne "-" ? sprintf "%.3f",$ll[11] : "-") : ($WGSread ? $ll[7] : $ll[3]);
	my ($cutoff_S,$drug_npv);
	if($mNGSread){
	    if(($ll[12] ne "-" && $ll[12] ne "/") && $patho_cov{$ll[0]} >= $ll[12]){
		$cutoff_S = $ll[13];
		$drug_npv = $ll[14]
	    }elsif(($ll[15] ne "-" && $ll[15] ne "/") && $patho_cov{$ll[0]} >= $ll[15]){
		$cutoff_S = $ll[16];
		$drug_npv = $ll[17];
	    }else{
		$cutoff_S = "-";
	    }
	}elsif($WGSread){
	    $cutoff_S = $ll[6];
	    $drug_npv = $ll[8];
	}else{
	    $cutoff_S = $ll[2];
	    $drug_npv = $ll[4];
	}
#$ll[0] eq "Acinetobacter baumannii" || next;
#$ll[1] eq "cephalosporin:cefepime" || next;
	$cutoff_S = ($cutoff_S ne "-" && $cutoff_S ne "/") ? sprintf "%.6f", $cutoff_S : "-";
	my $predict_ast = $scores >= $cutoff_R ? "R" : (($cutoff_S ne "-" && $scores < $cutoff_S) ? "S" : "/");
#print STDERR "$scores\t$cutoff_S\t$patho_cov{$ll[0]}\t$ll[15]\t$predict_ast\n";
	my $accuracy = $predict_ast eq "R" ? $drug_ppv : ($predict_ast eq "S" ? $drug_npv : "/");

	my $out = $out_gf_score ? "$ll[0]\t$ll[1]\t$report_args\t$scores\t$cutoff_R\t$predict_ast\t$accuracy\t$patho_rn{$ll[0]}\t$patho_cov{$ll[0]}\t$scores_gf\n" : "$ll[0]\t$ll[1]\t$report_args\t$scores\t$cutoff_R\t$predict_ast\t$accuracy\t$patho_rn{$ll[0]}\t$patho_cov{$ll[0]}\n";
	$patho_rn{$ll[0]} >= $min_rn && (print $out);
    }
}
close IN;

