#!/usr/bin/perl -w
use FindBin qw($Bin);

@ARGV || die "perl $0 <ARG.stat> > ARG.stat.filter\n";
###过滤涉及的主要指标:L5检出reads数排序优先保留top1、基因型检出all-like reads数排序优先保留top1、检出基因型间similarity、家族检出特异性reads数、基因型检出特异性reads数、基因型检出覆盖度及覆盖深度、基因型检出精确覆盖度。 
my $gt_similarity = "$Bin/card_db/pairGene.similarity.anno2.xls";
open SI,$gt_similarity;
my (%gt_sim);
while(<SI>){
    /^ARG1_gf/ && next;
    chomp;
    my @ll = split /\t/;
    $gt_sim{$ll[1]}{$ll[3]} ||= $ll[5];
    $gt_sim{$ll[1]}{$ll[3]} =  $gt_sim{$ll[1]}{$ll[3]} >= $ll[5] ? $gt_sim{$ll[1]}{$ll[3]} : $ll[5];
    $gt_sim{$ll[3]}{$ll[1]} = $gt_sim{$ll[1]}{$ll[3]};
}
close SI;

###=========
open IN,$ARGV[0] || die $!;
my (%uniq,%uniq2,%group_top1,%gt_cover,%all_like);###添加
while(<IN>){
    chomp;
    if(/^#/){print $_,"\n";next;}
    my @ll = split /\t/;
    $uniq{$ll[0]}{$ll[2]}++;
    $uniq2{$ll[0]}{$ll[2]}{$ll[4]}++;
    $group_top1{$ll[2]} ||= $ll[6];
    $all_like{$ll[2]}{$ll[3]}{$ll[6]}=$ll[11];#####20220419添加####
    my $mu = $ll[10]/$ll[1]; #all ARG-like read数与L5特异性reads数之比
    $mu > 2 && next; #若比对太高，表明从其他家族错误比对过来的reads数较本家族特异性检出的reads数要高，故大概率此时检出的基因家族是假阳性
    my @cov = split /\//,$ll[15];
#    ($cov[0] == 0 && $ll[16]<=0.6) && next;
    if($ll[10] >= 3 && $ll[16] <= 0.3){ #低覆盖度检出时，覆盖应该叫均匀
	($ll[14] >= 2 || $ll[17] <3) || next;
    }
    $ll[16] <= 0.3 && $ll[17] > 5 && next;
    $gt_cover{$ll[6]}= $ll[16]; 
    my @detect = keys %retain;
    if($uniq{$ll[0]}{$ll[2]} < 2){
	$ll[3] < 1 && next; #针对家族，有特异性reads检出>=1的才予以保留
    }elsif($ll[5] ==0 ){
	#针对家族内检出的各基因型,进行过滤
	if($all_like{$ll[2]}{$ll[3]}{$ll[6]} == $all_like{$ll[2]}{$ll[3]}{$group_top1{$ll[2]}}){
		print join("\t",@ll),"\n";
	}
    }else{
	if($retain{$group_top1{$ll[2]}}){  #如果家族内all-like reads数排top1的予以保留，则对top2/3进行过滤
	    my $gt_sim_max=0;
	    my $gt_sim_max_arg="";
	    for my $d(@detect){
		if($gt_sim{$ll[6]}{$d} && $gt_sim_max <= $gt_sim{$ll[6]}{$d}){
		    $gt_sim_max = $gt_sim{$ll[6]}{$d};
		    $gt_sim_max_arg = $d;
		}
	    }
	    if($gt_sim_max > 0.95){ #家族内top2/3/4，与top1的sim高于0.96的进行过滤
		if($cov[0] == $cov[2]){ #基因型检出精确覆盖度为1，予以保留
		    ;
		}else{
		    if($cov[1] == $cov[2]){
			my $spe_rn_cutoff = sprintf "%.0f",$ll[10]*((100-$gt_sim_max)/100);
			$ll[7] > $spe_rn_cutoff || next;
		    }else{
			next;
		    }
		}
	    }else{
		if($cov[0] == $cov[2] || $cov[1] == $cov[2]){
		    ;
		}else{
		    if($uniq2{$ll[0]}{$ll[2]}{$ll[4]} < 2){
		        $ll[5] < 1 && next;
		    }else{
		        if($gt_sim_max_arg){
		            $ll[16] >= $gt_cover{$gt_sim_max_arg} || next; #
		        }else{ 
		            $ll[9] > 2 || next; #基因型检测特异性reads数>2的予以保留，阈值待验证
		        }
		    }
		}
	    }
	}else{
	    $cov[0] == $cov[2] || next; 
	}
    }
  
    $retain{$ll[6]} = 1; #记录被保留的基因型
    print join("\t",@ll),"\n";
}
close IN;

