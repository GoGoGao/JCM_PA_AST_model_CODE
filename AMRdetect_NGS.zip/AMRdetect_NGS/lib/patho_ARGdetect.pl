#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Getopt::Long;
my %opt=();
my $vcf;
my $vfcut;
GetOptions(\%opt,"pathogen:s","detect_patho:s","arg2taxon:s","focus_species:s","patho_argCN:s","feature_weight:s","vcf:s"=>\$vcf,"vf_cutoff:s"=>\$vfcut);

@ARGV == 2 || die "perl $0 <arg.detect> <coverage.stat> --detect_patho <patho.detect> --arg2taxon <predict_arg2taxon> >drug_detect.xls\n";

#====== 数据库及参数设置 =======
#my $arg_anno_db = "$Bin/MEGARes2.1/megares_v2.1.2.info.xls";
$opt{focus_species} ||= "$Bin/report_db/focus_patho.list";
$opt{patho_argCN} ||= "$Bin/report_db/patho_ARG.CN.xls";
#$opt{feature_weight} ||= "$Bin/report_db/feature_weight.xls";
#$opt{feature_weight} ||="/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Analyse/paper_v1.1/Tables/03.key_feature/key_feature.xls";
$opt{feature_weight} ||="/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/LiubingWenzhang/06Tables/key_feature.xls";
$vfcut||=0.5;
#=============================== main function ===============================
my %gt2gf;
open IN,"/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/AMRdetect_v1.3_NGS/lib/card_db/card.info.xls";
<IN>;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$gt2gf{$or[9]}=$or[8];
}
close IN;
open IN,$opt{feature_weight} || die $!;
my %key_gf;
while(<IN>){
    /^#/ && next;
    my @ll = split /\t/;
#	if($ll[1]=~/\(/){
#		my @aa=split /\(/,$ll[1];
#		$aa[0]="oprD" if $	
#		$key_gf{$aa[0]} = 1;
#	}else{
	    $key_gf{$ll[1]} = 1;
#	}
}
close IN;

my %var;
open IN,$vcf;
my %checki;
while(<IN>){
	chomp;
	next if $_=~/^#/;
	my @or=split /\t/;
	my @anno=split /,/,$or[-3];
	my @hh=split /\|/,$anno[0];
	my @tt=split /:/,$or[-1];
	next if $tt[-1] <= $vfcut;
	if($hh[2]=~/HIGH/ and !$checki{$hh[3]}){
		push @{$var{$hh[3]}},"$hh[3](HIGH)";
		$checki{$hh[3]}=1;
	}
	next if $hh[2]=~/HIGH/;
	next unless $hh[10];
	push @{$var{$hh[3]}},"$hh[3]($hh[10])";
}
close IN;

##ARG的物种归属预测
my %arg_taxon;
if($opt{arg2taxon}){
    open IN,$opt{arg2taxon} || die $!;
    while(<IN>){
        chomp;
        /^#/ && next;
        my @ll = split /\t/;
		$arg_taxon{$ll[0]} = "$ll[2]\t$ll[4]";
    }
    close IN;
}

###物种基因拷贝数
my %spe_max_argCN;
if($opt{patho_argCN}){
    open IN,$opt{patho_argCN} || die $!;
    while(<IN>){
	chomp;
	my @ll = split /\t/;
	$spe_max_argCN{$ll[0]}{$ll[1]} = (split /,/,$ll[3])[1];
    }
    close IN;
}

##关注的报告病原菌范围
open IN,$opt{focus_species} || die $!;
my (%focus_spe,%spe_rn,%spe_cov,%spe_covxdepth);
while(<IN>){
    chomp;
    s/^\s+//;s/\s+$//;
    $focus_spe{$_} = 1;
    $spe_rn{$_} ||= 1;  #先默认设置为1
#    $spe_cov{$_} ||= 0.000001;
    $spe_covxdepth{$_} ||= 0.000001;
}
close IN;

###病原检出统计
my ($arg_detectf,$patho_detectf) = @ARGV;
open IN,$patho_detectf || die $!;
my (%spe2genus_cov_rn,%total_bac_rn);
while(<IN>){
    chomp;
    my @ll = split /\t/;
    $spe_rn{$ll[0]} = $ll[2];
    $spe_covxdepth{$ll[0]} = ($ll[5]*$ll[4])/100;
    $spe2genus_cov_rn{$ll[0]} = "$ll[4]\t$ll[5]\t$ll[2]\tNA";
    $total_bac_rn{"Bacteria"} = "NA";
}
close IN;

my %bsd_detect;
if($opt{detect_patho} && -s $opt{detect_patho}){
    open IN,$opt{detect_patho} || die $!;
    my %uniq = ();
    $total_bac_rn{"Bacteria"} = 0;
    my ($bac_rn_index,$genusName_index,$genus_rn_index,$speName_index,$spe_rn_index,$cov_index,$depth_index);
    my $h = <IN>;chomp $h;
    my @hh = split /\t/,$h;
    for my $i(0..$#hh){
        $hh[$i] eq "Kingdom" && ($bac_rn_index = $i);
        $hh[$i] eq "Genus拉丁名" && ($genusName_index = $i);
        $hh[$i] eq "属原始reads数" && ($genus_rn_index = $i);
        $hh[$i] eq "种拉丁名" && ($speName_index = $i);
        $hh[$i] eq "种原始reads数" && ($spe_rn_index = $i);
        $hh[$i] eq "Coverage(ratio)" && ($cov_index = $i);
        $hh[$i] eq "Depth" && ($depth_index = $i);
    }
    while(<IN>){
        chomp;
        my @ll = split /\t/;
        $ll[$cov_index] eq "-" && next;
        my $cov = (split /\(/,$ll[$cov_index])[0];$cov =~ s/\%//;
        my $depth = $ll[$depth_index];
	$bsd_detect{$ll[$speName_index]} = 1;
        if($focus_spe{$ll[$speName_index]}){
	    $spe_rn{$ll[$speName_index]} = $ll[$spe_rn_index]; #物种实际检出reads数
	    $spe_covxdepth{$ll[$speName_index]} = ($cov*$depth)/100; #用作后边计算ARG的拷贝数
	    $spe2genus_cov_rn{$ll[$speName_index]} = "$cov\t$depth\t$ll[$spe_rn_index]\t$ll[$genus_rn_index]"; #覆盖度、覆盖深度、种reads数、属reads数
        }
        $ll[$genusName_index] eq "-" && ($ll[$genusName_index] = $ll[$speName_index]); #属名称
        $uniq{$ll[$genusName_index]}++;
        $uniq{$ll[$genusName_index]} < 2 && ($total_bac_rn{$ll[$bac_rn_index]}+=$ll[$genus_rn_index]); #细菌总reads数
    }
    close IN;
}

###耐药基因检出
open IN,$arg_detectf || die $!;
my (%Patho_args,%is_locate,%not_locate);
my @focus_patho_sort = sort {$spe_rn{$b} <=> $spe_rn{$a}} keys %focus_spe;
while(<IN>){
    chomp;
    /^#/ && next;
    my @ll = split /\t/;
    my $mark = $key_gf{$ll[4]} ? "KEY" : "Non_KEY";
    my ($arg_taxons,$arg_born) = @ll[20,22];
    my @predict_spe;
	#print $_,"\n";
    $arg_taxon{$ll[4]} && (@predict_spe = split /\t/,$arg_taxon{$ll[4]});
#$ll[4] eq  "SHV beta-lactamase" && (print STDERR "@predict_spe\n");
    my $cycle = 1;
    CY:{;}
    for my $spe(@focus_patho_sort){
	$opt{detect_patho} && ($bsd_detect{$spe} || next);
	$spe_covxdepth{$spe} == 0.000001 && next;
	$spe_covxdepth{$spe} > 0 || next;
	my $arg_copy_n = sprintf "%.2f",($ll[16]*$ll[17])/$spe_covxdepth{$spe};
	$arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
	$spe_max_argCN{$spe}{$ll[2]} ||= 1.5;
	print STDERR "$mark\t$ll[4];$ll[6],$ll[10]\t$spe;0.2~$spe_max_argCN{$spe}{$ll[2]}+3\tCycle$cycle\t$arg_copy_n";
#	$cycle > 10 && ($arg_copy_n = 1);
	if($arg_copy_n >= $spe_max_argCN{$spe}{$ll[2]}+3 || $arg_copy_n <= 0.2){
	    print STDERR "\tNO";  #未定位到基因的物种来源
	    if($ll[10] >= 3){ #数据量较高时，计算得到的拷贝数也是比较稳定的，即重复稳定好。而数据量低时，计算得到的拷贝数容易波动大。
		print STDERR "\n";
                next;
	    }else{ #针对基因检出reads数低于3条的，考虑可能由于计算出来的拷贝数波动较大，此处增加一轮拷贝数的计算。
		my $cycle_tmp = $cycle;
		my $locate_mark = 0;
#		for my $n(1 .. 2){
#		    $cycle_tmp += 1;
#		    my $arg_copy_n_tmp = $arg_copy_n > 1 ? sprintf "%.2f",$arg_copy_n/$cycle_tmp : sprintf "%.2f",$arg_copy_n*$cycle_tmp;
#		    if($arg_copy_n_tmp >= 0.5 && $arg_copy_n_tmp <= $spe_max_argCN{$spe}{$ll[2]}+3){
#			print STDERR " ... RN<3:Cycle$cycle_tmp,$arg_copy_n_tmp\tYES\n";
#			$locate_mark = 1;
#			last;
#		    }
#		}
		$locate_mark || ((print STDERR "\n")  && next);
	    }
	}else{print STDERR "\tYES\n";} #定位到基因的物种来源
	#print $_,"\n";
	my $name=$ll[6];
	$name="oprN"  if $name eq "OprN";
	$name="parS" if $name eq "ParS";
	$name="parR" if $name eq "ParR";
#	$name="oprD" if $name eq "Pseudomonas aeruginosa oprD with mutation conferring resistance to imipenem";
	$name="parC" if $name eq "Pseudomonas aeruginosa gyrA and parC conferring resistance to fluoroquinolones";
	$name="gyrA" if $name eq "Pseudomonas aeruginosa gyrA conferring resistance to fluoroquinolones";
	$name="gyrB" if $name eq "Pseudomonas aeruginosa gyrB conferring resistance to fluoroquinolones";
	$name="parE" if $name eq "Pseudomonas aeruginosa parE conferring resistance to fluoroquinolones";
	#print $name,"\n";
	my $vars=$var{$name} ? join(",",@{$var{$name}}) : $ll[18];
	my $focus_genus = (split /\s+/,$spe)[0]; #第一种是直接数据库记录或预测的arg来源物种与关注物种匹配，第二种是数据库记录或预测的arg来源物种所在属和关注的物种genus水平相同，第三种是数据库记录或预测的基因归属物种与关注物种不一致，此时看耐药是否存在质粒介导方式
	if($arg_taxons =~ /$spe/ig || $arg_taxons =~ /$focus_genus/ig ){
	    $Patho_args{$spe} .= "$spe\tDB_taxon_anno\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n(cycle$cycle)\t$ll[19]\t$vars\n";
	    $is_locate{"$ll[4]\t$ll[6]"} = 1;
	}elsif($arg_born =~ /plasmid|transposon/){
	    $Patho_args{$spe} .= "$spe\tplasmid|transposon\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n(cycle$cycle)\t$ll[19]\t$vars\n";
	    $is_locate{"$ll[4]\t$ll[6]"} = 1;
	}elsif($arg_taxon{$ll[4]}){
	    my $focus_genus = (split /\s+/,$spe)[0]; #第一种是直接数据库记录或预测的arg来源物种与关注物种匹配，第二种是数据库记录或预测的arg来源物种所在属和关注的物种genus水平相同，第三种是数据库记录或预测的基因归属物种与关>注物种不一致，此时看耐药是否存在质粒介导方式
            if($predict_spe[1] =~ /$spe/ig || $predict_spe[0] =~ /$focus_genus/ig){
                $Patho_args{$spe} .= "$spe\tread_taxon_anno\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n(cycle$cycle)\t$ll[19]\t$vars\n";
                $is_locate{"$ll[4]\t$ll[6]"} = 1;
            }
	}
    }

    if(!$is_locate{"$ll[4]\t$ll[6]"} && $cycle <= 10){
	if($key_gf{$ll[4]}){$cycle++;goto (CY);}
    }
    print STDERR "\n";
}
close IN;

###output
print "#focus_patho\tmethod\tdetect_gf\tgf_rn\tdetect_gt\tgt_rn(specific|ARG-like)\tcopy_num\tmodel_type\tVaration\tgenome_coverage(%)\tAvgDepth\tspe_rn\tgenus_rn\ttotal_Bac_rn\n";
for my $spe(sort keys %Patho_args){
    $opt{pathogen} && $opt{pathogen} ne $spe && next;
    my @lines = split /\n/,$Patho_args{$spe};
    for my $line(@lines){
	print "$line\t$spe2genus_cov_rn{$spe}\t$total_bac_rn{Bacteria}\n";
    }
}

