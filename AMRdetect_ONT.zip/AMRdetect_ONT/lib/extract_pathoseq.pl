#!/usr/bin/perl -w
use strict;

@ARGV || die "perl $0 <.tax> <nohost.fa> > pathogen.fa\n";
open IN,$ARGV[0];
my %hash;
while(<IN>){
    chomp;
    /^#/ && next;
    my @ll=split /\t/;
    $hash{$ll[0]}=1;
}
close IN;
open IN,$ARGV[1];
$/=">";<IN>;
while(<IN>){
    chomp;
    my $id=$1 if($_=~/^(\S+)/);
    $hash{$id} && (print ">$_");
}
$/ ="\n";
close IN;
