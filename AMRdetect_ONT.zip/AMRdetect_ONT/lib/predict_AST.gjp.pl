#!usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Getopt::Long;
my $platform;
 GetOptions("platform:s"=>\$platform);
$platform||="ONT";
my ($in)=@ARGV;
@ARGV || die "
	#Description：预测临床样本RS表型  判定逻辑：基于cutoff表（某病原不同深度下/Coverage下报告RS的score阈值）来分析临床样本AST
	#Date: 20220221 
	#Version: v0.1
	#Email: gjpbioinfo\@163.com

\n";
my $cardinfo="$Bin/card_db/card.info.xls";
my $gt_similarity="$Bin/card_db/pairGene.similarity.anno2.xls";
my %gene2genefamily;
open IN,$cardinfo;
<IN>;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$gene2genefamily{$or[9]}=$or[8];
}
close IN;

my %weight;
my %keygf;
open IN,"$Bin/report_db/feature_weight.xls";
<IN>;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$or[0]=~s/\s+/_/g;
	$or[1]=~s/-/_/g;
	$or[1]=~s/\s+/_/g;
	if($or[3] eq "homolog"){
		$keygf{$or[0]}{$or[1]}{$or[4]}{weight}=$or[5];#关键基因家族权重
		my @ppp=split /\(/,$or[6];
		$keygf{$or[0]}{$or[1]}{$or[4]}{ppv}=$ppp[0]; #关键基因家族PPV
		push @{$keygf{$or[0]}{$or[1]}{$or[4]}{genes}},$or[7] if $or[7] ne "-"; #
	}
	$weight{$or[0]}{$or[1]}{$or[7]}=$or[8];  #物种 药物 特征 => 权重
}
close IN;

my $sp_reads;
my %coverage;
my %detected_args;
open IN,$in;#检出的基因型、变异数据
<IN>;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$or[0]=~s/\s+/_/g;
	$coverage{$or[0]}=$or[9];
	$sp_reads||=$or[11];
	$detected_args{$or[0]}{$or[4]}=1; #基因型 L2  基因型之间先后反应检出的基因型准确性，这地方不能用哈希存
	if($or[8] ne "NA" and $or[8]  ne "0"){ #存在变异位点检出
		foreach my $var (split /,/,$or[8]){
			if($or[4] eq "oprD" and $var=~/HIGH/){
				$detected_args{$or[0]}{"$or[4](HIGH)"}=1;
				next;
			}
			my @vv=split /\|/,$var;
			$vv[-1]=~s/\)//g;
#			3556431:2768(T->G)|0.500|1/2|MODERATE|missense_variant|c.2768A>C|p.Glu923Ala)
			$detected_args{$or[0]}{"$or[4]($vv[-1])"}=1; 
		}
	}
}
close IN;

open SI,$gt_similarity;
my (%gt_sim);
while(<SI>){
    /^ARG1_gf/ && next;
    chomp;
    my @ll = split /\t/;
    $gt_sim{$ll[1]}{$ll[3]} ||= $ll[5];
    $gt_sim{$ll[1]}{$ll[3]} =  $gt_sim{$ll[1]}{$ll[3]} >= $ll[5] ? $gt_sim{$ll[1]}{$ll[3]} : $ll[5];
    $gt_sim{$ll[3]}{$ll[1]} = $gt_sim{$ll[1]}{$ll[3]};
}
close SI; 

my %trainingset_ppv;
open IN,"$Bin/report_db/ARG_ppv.stat";
while(<IN>){
	chomp;
	my @or=split /\t/;
	$or[0]=~s/\s+/_/g;
	$or[1]=~s/:/--/g;
	my @aa=split /\//,$or[-1];
	$trainingset_ppv{$or[0]}{$or[1]}{$or[3]}{ppv}=$or[4];
	$trainingset_ppv{$or[0]}{$or[1]}{$or[3]}{gn}=$aa[0];
}
close IN;


print "#Patho\tdrug\tdetect_ARGs\tscores\tcutoff\tpredict\taccuracy\tpatho_rn\tpatho_coverage\n";
foreach my $tax (sort keys %weight){
	next unless $coverage{$tax}; #仅title行无耐药基因检出
	foreach my $drug (sort keys %{$weight{$tax}}){
		my $detected_features;
		my $detected_features_score;
		my %mark;
		foreach my $feature ( sort keys %{$detected_args{$tax}}){
#			print STDERR $feature,"\n";
			if($weight{$tax}{$drug}{$feature} and !$mark{$feature}){ #有检出该关键特征
				$detected_features.="$feature;";
				$detected_features_score+=$weight{$tax}{$drug}{$feature};
				$mark{$feature}=1;  #qacL基因L2层级名称相同，只加一次
				print STDERR "###$tax	coverage:$coverage{$tax}	$drug	$feature 关键特征直接加和score\n";
				if($gene2genefamily{$feature}){  #已经加和过的基因型如同时携带KPC-2，KPC-51，不再对KPC-51的family加和
					$mark{$gene2genefamily{$feature}}=1;	
				}
			}elsif($feature=~/\)\)/){  #变异特征next
				next;
			}elsif($gene2genefamily{$feature}){ #存在基因家族的gt，即非变异特征
				#基因家族在特征基因家族范围内
				next if $mark{$gene2genefamily{$feature}};
				if($keygf{$tax}{$drug}{$gene2genefamily{$feature}}){
					#召回基因家族score的几种情况：在家族PPV>0.95前提条件下满足如下情况也考虑召回 1）与特征基因相似性>0.95 2）训练集中基因型的PPV>0.9且基因组数目>3
	#				print STDERR $tax,"\t",$drug,"\t",$gene2genefamily{$feature},"\t",$keygf{$tax}{$drug}{$gene2genefamily{$feature}}{ppv},"\n";
					if($keygf{$tax}{$drug}{$gene2genefamily{$feature}}{ppv} > 0.95){ #对PPV>0.95的特别重要基因家族召回基因家族
						my $add_gf=0;
						
						foreach my $gene( @{$keygf{$tax}{$drug}{$gene2genefamily{$feature}}{genes}}){
							if($gt_sim{$gene}{$feature} && $gt_sim{$gene}{$feature}> 0.95){ #与关键基因家族的相似性大于0.95
								$add_gf=1;
							}
						}	
							
						if($trainingset_ppv{$tax}{$drug}{$feature}{ppv} and $trainingset_ppv{$tax}{$drug}{$feature}{gn} >=3){
							$add_gf=2; 
						}
						if($add_gf == 0){#如果与关键特征基因之间容易分型，即相似性<95%;
							$detected_features.="$gene2genefamily{$feature};";
							$detected_features_score+=$keygf{$tax}{$drug}{$gene2genefamily{$feature}}{weight};
							print STDERR "###$tax   coverage:$coverage{$tax}    $drug   $feature 正常加和\n";
							$mark{$gene2genefamily{$feature}}=1;
							next;
						
						}elsif($add_gf==1){ #可能为基因分型不准导致的偏差或者训练集没有训练出来但是PPV及GN也OK
							$detected_features.="$gene2genefamily{$feature}";
							$detected_features_score+=$keygf{$tax}{$drug}{$gene2genefamily{$feature}}{weight};
							print STDERR "###$tax	coverage:$coverage{$tax}	$drug	$feature 与关键基因家族的相似性大于0.95,加和家族权重\n";
							$mark{$gene2genefamily{$feature}}=1;
						}else{
							$detected_features.="$gene2genefamily{$feature}";
							$detected_features_score+=$keygf{$tax}{$drug}{$gene2genefamily{$feature}}{weight};
							print STDERR "###$tax	coverage:$coverage{$tax}	$drug	$feature	训练集中基因型的PPV>0.9且基因组数目>3\n";
							$mark{$gene2genefamily{$feature}}=1;
						}
					}else{
						next;  #不是PPV>0.95的基因家族不考虑
					}
				}else{
					next; #不是关键特征基因家族不考虑
				}
			}else{
			  print STDERR "!!! $tax $drug $feature 非关键特征，过滤\n";   
			  next;
			}
		}
		my ($R_cutoff,$S_cutoff)=split /\|/,getcutoff($tax,$drug,$coverage{$tax});
		$detected_features_score||="0";
		my $report_RS;
		#print $R_cutoff,"\t",$S_cutoff,"\n";
		if($R_cutoff ne "/" && $detected_features_score >= $R_cutoff){
			$report_RS="R";
		}elsif($S_cutoff ne "/" && $detected_features_score < $S_cutoff){
			$report_RS="S";	
		}else{
			$report_RS="/";
		}
		$detected_features||="/";
		$detected_features=~s/;$//g;
		print $tax,"\t",$drug,"\t",$detected_features,"\t",$detected_features_score,"\t","R:$R_cutoff|S:$S_cutoff","\t",$report_RS,"\t","/","\t",$sp_reads,"\t",$coverage{$tax},"\n";
	}
}

sub getcutoff{
	my ($tax,$drug,$coverage)=@_;
	#print($coverage),"\n";
	my $depth_cutoff||=0;
	open IN,"$Bin/pathogen_depth_coverage";  #某病原不同数据量下模拟深度与coverage的关系
	<IN>;
	while(<IN>){
		chomp;
		my @or=split /\t/;
		next if $or[0] ne $tax;
		my @aa=split /\(/,$or[3];
		if($coverage > $aa[0]){
			$depth_cutoff=$or[2];
		}else{
			last;
		}
	}
	close IN;

	
	my $cutoff||="/:/";
	open IN,"$Bin/report_db/set.cutoff.detail.xls";
	<IN>;
	while(<IN>){
		chomp;
		my @or=split /\t/;
		$or[0]=~s/\s+/_/g;
		$or[1]=~s/--/:/g;
#		print STDERR $or[0],"\t",$or[1],"\t",$drug,"\t",$depth_cutoff,"\n";
		if($or[0] eq $tax and $or[1] eq $drug and $or[4] == $depth_cutoff){
#			print STDERR $or[0],"\t",$or[1],"\t",$drug,"\t",$depth_cutoff,"\n";
			$cutoff=$or[3];
		}
	}
	close IN;
	my @cut=split /:/,$cutoff;
	return ($cut[0]."|".$cut[1])
}
