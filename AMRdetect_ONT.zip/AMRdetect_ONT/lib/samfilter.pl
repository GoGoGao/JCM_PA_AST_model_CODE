#!usr/bin/perl -w
use strict;

my ($anno,$in,$out)=@ARGV;

my %hash;
open IN,$anno;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$hash{$or[0]}=1;
}
close IN;

open IN,"/data/GensKey/Work/gaojianpeng/work/Tools/Software/samtools-1.9/bin/samtools view -h $in | ";
#open OUT," > /data/GensKey/Work/gaojianpeng/work/Tools/Software/samtools-1.9/bin/samtools view -bh > $out";
while(<IN>){
	chomp;
	if($_=~/^\@/){
		print $_,"\n";
	}else{
		my @or=split /\t/;
		print  $_,"\n" if $hash{$or[0]};
	}
}
close IN;
#close OUT;
