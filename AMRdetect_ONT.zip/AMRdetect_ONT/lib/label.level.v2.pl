#!usr/bin/perl -w
use strict;

my ($in)=@ARGV;
#20200303 脚本功能 对oprD变异程度进行类别划分，发生>=1次HIGH级别变异，则判定样本存在HIGH变异；对非HIGH，按照原始突变位点输出；未检出基因为缺失模型，记作Notdetected；


my %key;
#open IN,"/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Analyse/LIST/keyvar.genename.sort";
open IN,"/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/lib/lib/arg.drug";
while(<IN>){
    chomp;
	next if $_=~/#/;
	my @or=split /\t/;
	foreach my $i (@or[1..$#or]){
		$key{$i}=1;
	}
}
close IN; 

open IN,$in;
my $line=<IN>;
chomp $line;
my @title=split /\t/,$line;
my %hash;
my %lab;
while(<IN>){
	chomp;
	my @or=split /\t/;
	my @vv=split /,/,$or[-1];
	my @ll=split /\|/,$vv[0];
	next if $vv[0]=~/LOW/;
	next unless $ll[3];
#	unless ($ll[3] eq "oprD" or $ll[3] eq "wbpL" or $ll[3] eq "wspR" or $ll[3] eq "wspL" or $ll[3] eq "wspA" or $ll[3] eq "gyrA" or $ll[3] eq "parE" ){
	unless($key{$ll[3]}){
		next;
	}
	#my $label=$vv[0]=~/HIGH/ ? "$gene\_HIGH" : $vv[0]=~/LOW/ ? "$gene\_LOW" : "$gene\_MODERATE";
	$ll[10] || next;
	
	my $label=$vv[0]=~/HIGH/ ? "$ll[3](HIGH)" : "$ll[3]($ll[10]):$ll[2]";
	#my $label;
#	if($vv[0]=~/HIGH/){
#		if($ll[3] eq "oprD"){
#			$label="$ll[3](HIGH)";
#		}else{
#			$label="$ll[3]($ll[10]):HIGH";
#		}
#	}else{
#		$label="$ll[3]($ll[10]):$ll[2]";	
#	}

	$lab{$label}=1;
#	print $label,"\t",$or[-1],"\n";
	foreach my $i (1..$#or-1){
		$hash{$title[$i]}{$label}+=$or[$i];
	}
}
close IN;
if(0){
foreach my $s (sort keys %hash){
	my %sum;
	foreach my $v (sort keys %{$hash{$s}}){
		my @tmp=split /\(/,$v;
		$sum{$tmp[0]}+=$hash{$s}{$v};
	}
	foreach my $g (sort keys %sum){
		$hash{$s}{"$g(ND)"}=1 if $sum{$g}==0;  #基因上没有任何一个变异存在判定为缺失模型
		$lab{"$g(ND)"}=1;
	}
}
}
my @lbs=sort keys %lab;
print "#var\t",join("\t",@title[1..$#title-1]),"\n";
foreach my $l (@lbs){
#	next if $l!~/ND/ and $l!~/HIGH/;
	print $l;
	foreach my $s (@title[1..$#title-1]){
		$hash{$s}{$l}||=0;
		$hash{$s}{$l}=1 if $hash{$s}{$l}>0;
		#print STDERR $s,"\t",$l,"\t",$hash{$s}{$l},"\n";
		print "\t",$hash{$s}{$l};
	}
	print "\n";
}
