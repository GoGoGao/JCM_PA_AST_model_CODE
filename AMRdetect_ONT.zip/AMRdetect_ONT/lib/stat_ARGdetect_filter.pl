#!/usr/bin/perl -w
use FindBin qw($Bin);

@ARGV || die "perl $0 <ARG.stat> > ARG.stat.filter\n";
#my $gt_similarity = "$Bin/card_db/pairGene.identity.anno2.xls";
my $gt_similarity = "$Bin/card_db/pairGene.similarity.anno2.xls";
open SI,$gt_similarity;
my %gt_sim;
<SI>;
while(<SI>){
    chomp;
    my @ll = split /\t/;
    $gt_sim{$ll[1]}{$ll[3]} ||= $ll[5];
    $gt_sim{$ll[1]}{$ll[3]} = $gt_sim{$ll[1]}{$ll[3]} > $ll[5] ? $gt_sim{$ll[1]}{$ll[3]} : $ll[5];
    $gt_sim{$ll[3]}{$ll[1]} = $gt_sim{$ll[1]}{$ll[3]};
}
close SI;

open IN,$ARGV[0] || die $!;
my (%uniq,%group_top1,%gt_cover);
while(<IN>){
    chomp;
    if(/^#/){print $_,"\n";next;}
    my @ll = split /\t/;
    $uniq{$ll[0]}{$ll[2]}++;
    $group_top1{$ll[2]} ||= $ll[6];
    $ll[15] < 0.3 && $ll[16] > 3 && next; #异常检出，
    $gt_cover{$ll[6]} = $ll[15];
    my @detect = keys %retain;
    if($uniq{$ll[0]}{$ll[2]} < 2){
	$ll[5] < 1 && next; #针对家族，有特异性reads检出>=1的才予以保留
    }else{
	if($retain{$group_top1{$ll[2]}}){
	    my $gt_sim_max=0;
	    my $gt_sim_max_arg="";
	    for my $d(@detect){
		if($gt_sim{$ll[6]}{$d} && $gt_sim_max <= $gt_sim{$ll[6]}{$d}){
		    $gt_sim_max = $gt_sim{$ll[6]}{$d};
		    $gt_sim_max_arg = $d;
		}
	    }
	    if($gt_sim_max > 0.95){ #对于家族内非top1检出的，目标基因在家族内与top1的sim高于0.95的直接滤掉
		next;
	    }else{
		if($gt_sim_max_arg){
		    $ll[15] > $gt_cover{$gt_sim_max_arg} || next;
		}else{
		    ($ll[9] > 2) || next; #对于家族内非top1检出的，目标基因在家族内top1的sim小于0.95的，根据基因型检测特异性reads数进行过滤。阈值设置为2是否太宽松？
		}
	    }
	}else{
	    next;
	}
    }
    $retain{$ll[6]} = 1;
    print join("\t",@ll),"\n";
}
close IN;

