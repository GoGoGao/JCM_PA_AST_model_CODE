#!usr/bin/perl -w
use strict;

my ($add,$in)=@ARGV;

my %hash;
open IN,$add;
while(<IN>){
	chomp;
	my @or=split /\t/;
	next if $or[1]=~/synonymous_variant/;
	#my @aa=split /\|/,$or[1];
	$hash{$or[0]}{$or[1]}=1;
}
close IN;

open IN,$in;
my $one=<IN>;
print $one;
while(<IN>){
	chomp;
	my @or=split /\t/;
	if($hash{$or[4]}){
		my $var=join(",",sort keys %{$hash{$or[4]}});
		print join("\t",@or[0..7]),"\t",join("\t",@or[9..$#or]),"\n";
	}else{
		print $_,"\n";
	}
}
close IN;
