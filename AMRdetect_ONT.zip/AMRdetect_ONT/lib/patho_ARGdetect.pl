#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Getopt::Long;
my $var;
my $af_cutoff;
my $reads_cutoff;
my %opt=();
GetOptions(\%opt,"pathogen:s","detect_patho:s","arg2taxon:s","focus_species:s","patho_argCN:s","feature_weight:s","var:s"=>\$var,"af_cutoff:s"=>\$af_cutoff,"reads_cutoff:s"=>\$reads_cutoff);

@ARGV == 2 || die "perl $0 <arg.detect> <coverage.stat> --detect_patho <patho.detect> --arg2taxon <predict_arg2taxon> >drug_detect.xls\n";

#====== 数据库及参数设置 =======
#my $arg_anno_db = "$Bin/MEGARes2.1/megares_v2.1.2.info.xls";
$opt{focus_species} ||= "$Bin/report_db/focus_patho.list";
$opt{patho_argCN} ||= "$Bin/report_db/patho_ARG.CN.xls";
$opt{feature_weight} ||= "$Bin/report_db/feature_weight.xls";
$af_cutoff||=0.5;
$reads_cutoff||=1;
#=============================== main function ===============================

my %vars;
open IN,$var;
my %checki;
while(<IN>){
    chomp;
    next if $_=~/^#/;
    my @or=split /\t/;
    my @anno=split /,/,$or[-3];
    my @hh=split /\|/,$anno[0];
    my @tt=split /:/,$or[-1];
    next if $tt[-1] <= $af_cutoff;
	print STDERR $hh[2],"\t",$hh[3],"\t",$hh[10],"\t",$or[-1],"\n";
    if($hh[2]=~/HIGH/ and !$checki{$hh[3]}){
        push @{$vars{$hh[3]}},"$hh[3](HIGH)";
        $checki{$hh[3]}=1;
    }   
    next if $hh[2]=~/HIGH/;
    next unless $hh[10];
    push @{$vars{$hh[3]}},"$hh[3]($hh[10])";
}
close IN; 

open IN,$opt{feature_weight} || die $!;
my %key_gf;
while(<IN>){
    /^#/ && next;
    my @ll = split /\t/;
    $key_gf{$ll[1]} = 1;
}
close IN;

##ARG的物种归属预测
my %arg_taxon;
if($opt{arg2taxon}){
    open IN,$opt{arg2taxon} || die $!;
    while(<IN>){
        chomp;
        /^#/ && next;
        my @ll = split /\t/;
	$arg_taxon{$ll[0]} = "$ll[2]\t$ll[4]";
    }
    close IN;
}

###物种基因拷贝数
my %spe_max_argCN;
if($opt{patho_argCN}){
    open IN,$opt{patho_argCN} || die $!;
    while(<IN>){
	chomp;
	my @ll = split /\t/;
	$spe_max_argCN{$ll[0]}{$ll[7]} = (split /,/,$ll[3])[1];
    }
    close IN;
}

##关注的报告病原菌范围
open IN,$opt{focus_species} || die $!;
my (%focus_spe,%spe_rn,%spe_cov,%spe_covxdepth);
while(<IN>){
    chomp;
    s/^\s+//;s/\s+$//;
    $focus_spe{$_} = 1;
    $spe_rn{$_} ||= 1;  #先默认设置为1
#    $spe_cov{$_} ||= 0.000001;
    $spe_covxdepth{$_} ||= 0.000001;
}
close IN;

###病原检出统计
my ($arg_detectf,$patho_detectf) = @ARGV;
open IN,$patho_detectf || die $!;
my (%spe2genus_cov_rn,%total_bac_rn);
while(<IN>){
    chomp;
    my @ll = split /\t/;
	#Pseudomonas aeruginosa  GCF_000006765.1 6089903/6264404 97.214  30.4
    $spe_rn{$ll[0]} = "NA";
    $spe_covxdepth{$ll[0]} = ($ll[3]*$ll[4])/100;
    $spe2genus_cov_rn{$ll[0]} = "$ll[3]\t$ll[4]\tNA\tNA";
    $total_bac_rn{"Bacteria"} = "NA";
}
close IN;

if($opt{detect_patho} && -s $opt{detect_patho}){
    open IN,$opt{detect_patho} || die $!;
    my %uniq = ();
    $total_bac_rn{"Bacteria"} = 0;
    my ($bac_rn_index,$genusName_index,$genus_rn_index,$speName_index,$spe_rn_index,$cov_index,$depth_index);
    my $h = <IN>;chomp $h;
    my @hh = split /\t/,$h;
    for my $i(0..$#hh){
        $hh[$i] eq "Kingdom" && ($bac_rn_index = $i);
        $hh[$i] eq "Genus拉丁名" && ($genusName_index = $i);
        $hh[$i] eq "属原始reads数" && ($genus_rn_index = $i);
        $hh[$i] eq "种拉丁名" && ($speName_index = $i);
        $hh[$i] eq "种原始reads数" && ($spe_rn_index = $i);
        $hh[$i] eq "Coverage(ratio)" && ($cov_index = $i);
        $hh[$i] eq "Depth" && ($depth_index = $i);
    }
    while(<IN>){
        chomp;
        my @ll = split /\t/;
        $ll[$cov_index] eq "-" && next;
        my $cov = (split /\(/,$ll[$cov_index])[0];$cov =~ s/\%//;
        my $depth = $ll[$depth_index];
        if($focus_spe{$ll[$speName_index]}){
	    $spe_rn{$ll[$speName_index]} = $ll[$spe_rn_index]; #物种实际检出reads数
	    $spe_covxdepth{$ll[$speName_index]} = ($cov*$depth)/100; #用作后边计算ARG的拷贝数
	    $spe2genus_cov_rn{$ll[$speName_index]} = "$cov\t$depth\t$ll[$spe_rn_index]\t$ll[$genus_rn_index]"; #覆盖度、覆盖深度、种reads数、属reads数
        }
        $ll[$genusName_index] eq "-" && ($ll[$genusName_index] = $ll[$speName_index]); #属名称
        $uniq{$ll[$genusName_index]}++;
        $uniq{$ll[$genusName_index]} < 2 && ($total_bac_rn{$ll[$bac_rn_index]}+=$ll[$genus_rn_index]); #细菌总reads数
    }
    close IN;
}

###耐药基因检出
open IN,$arg_detectf || die $!;
my (%Patho_args,%is_locate,%not_locate);
my @focus_patho_sort = sort {$spe_rn{$b} <=> $spe_rn{$a}} keys %focus_spe;
while(<IN>){
    chomp;
    /^#/ && next;
    my @ll = split /\t/;
    my ($arg_taxons,$arg_born) = @ll[18,20];
    my @predict_spe;
    $arg_taxon{$ll[4]} && (@predict_spe = split /\t/,$arg_taxon{$ll[4]});
#$ll[4] eq  "SHV beta-lactamase" && (print STDERR "@predict_spe\n");
    my ($locate_mark,$cycle) = (0,1);
	my @tmp=();
	    my $name=$ll[6];
    $name="oprN"  if $name eq "OprN";
    $name="parS" if $name eq "ParS";
    $name="parR" if $name eq "ParR";
#   $name="oprD" if $name eq "Pseudomonas aeruginosa oprD with mutation conferring resistance to imipenem";
    $name="parC" if $name eq "Pseudomonas aeruginosa gyrA and parC conferring resistance to fluoroquinolones";
    $name="gyrA" if $name eq "Pseudomonas aeruginosa gyrA conferring resistance to fluoroquinolones";
    $name="gyrB" if $name eq "Pseudomonas aeruginosa gyrB conferring resistance to fluoroquinolones";
    $name="parE" if $name eq "Pseudomonas aeruginosa parE conferring resistance to fluoroquinolones";

	$vars{$name}||=\@tmp;
	my $varinfo=join(",",@{$vars{$name}}); #整合变异信息 20220118
	$varinfo||="NA";
    CY:{;}
    for my $spe(@focus_patho_sort){
		$spe_covxdepth{$spe} == 0.000001 && next; #关注的物种没有检出 next
		my $arg_copy_n = sprintf "%.2f",($ll[15]*$ll[16])/$spe_covxdepth{$spe};
		$arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
		$spe_max_argCN{$spe}{$ll[6]} ||= 3;
		$cycle == 1 && (print STDERR "$ll[6]\t$arg_copy_n\t$spe\t$spe_max_argCN{$spe}{$ll[6]}+3\tCycle$cycle\n");
		$cycle > 1 && (print STDERR "$ll[6]\t$arg_copy_n\t$spe\t$spe_max_argCN{$spe}{$ll[6]}+3\tCycle$cycle\n");
		$cycle >= 50 && ($arg_copy_n = 1);
		($arg_copy_n >= $spe_max_argCN{$spe}{$ll[6]}+3 || $arg_copy_n < 0.001) && next; #基因copy数一般不超过20,且不能小于0.4  #20220216 0.4改为0.05
		my $focus_genus = (split /\s+/,$spe)[0]; #第一种是直接数据库记录或预测的arg来源物种与关注物种匹配，第二种是数据库记录或预测的arg来源物种所在属和关注的物种genus水平相同，第三种是数据库记录或预测的基因归属物种与关注物种不一致，此时看耐药是否存在质粒介导方式
		if($arg_taxons =~ /$spe/ig || $arg_taxons =~ /$focus_genus/ig ){
	    	$Patho_args{$spe} .= "$spe\tDB_taxon_anno\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n\t$ll[17]\t$varinfo\n";
		    $is_locate{"$ll[4]\t$ll[6]"} = 1;
		    $locate_mark = 1;
		}
    }
    if($locate_mark == 0 && $arg_born =~ /plasmid/){
#		print STDERR $_,"\n";
        for my $spe(@focus_patho_sort){
	   		$spe_covxdepth{$spe} == 0.000001 && next;
            my $arg_copy_n = sprintf "%.2f",($ll[15]*$ll[16])/$spe_covxdepth{$spe};
            $arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
            $spe_max_argCN{$spe}{$ll[6]} ||= 3;
	    	$cycle >= 50 && ($arg_copy_n = 1);
	    	($arg_copy_n >= $spe_max_argCN{$spe}{$ll[6]}+3 || $arg_copy_n <= 0.001) && next; #基因copy数一般不超过20,且不能小于0.4
	    	$Patho_args{$spe} .= "$spe\tplasmid\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n\t$ll[17]\t$varinfo\n";
            $is_locate{"$ll[4]\t$ll[6]"} = 1;
	    	$locate_mark = 1;
        }
    }
    if($locate_mark == 0 && $arg_taxon{$ll[4]}){
        for my $spe(@focus_patho_sort){
            $spe_covxdepth{$spe} == 0.000001 && next;
            my $arg_copy_n = sprintf "%.2f",($ll[15]*$ll[16])/$spe_covxdepth{$spe};
            $arg_copy_n = $arg_copy_n > 1 ? $arg_copy_n/$cycle : $arg_copy_n*$cycle;
            $spe_max_argCN{$spe}{$ll[6]} ||= 3;
            $cycle >= 50 && ($arg_copy_n = 1);
            ($arg_copy_n >= $spe_max_argCN{$spe}{$ll[6]}+3 || $arg_copy_n <= 0.001) && next; #基因copy数一般不超过20,且不能小于0.1
            my $focus_genus = (split /\s+/,$spe)[0]; #第一种是直接数据库记录或预测的arg来源物种与关注物种匹配，第二种是数据库记录或预测的arg来源物种所在属和关注的物种genus水平相同，第三种是数据库记录或预测的基因归属物种与关>注物种不一致，此时看耐药是否存在质粒介导方式
	    	if($predict_spe[1] =~ /$spe/ig || $predict_spe[0] =~ /$focus_genus/ig){
				$Patho_args{$spe} .= "$spe\tread_taxon_anno\t$ll[4]\t$ll[5]\t$ll[6]\t$ll[7]|$ll[10]\t$arg_copy_n\t$ll[17]\t$varinfo\n";
	    	    $is_locate{"$ll[4]\t$ll[6]"} = 1;
	        	$locate_mark = 1;
	    	}
        }
    }

    my $mark = $key_gf{$ll[4]} ? "Key" : "Non_key";
    if(!$is_locate{"$ll[4]\t$ll[6]"} && $cycle < 50){
		print STDERR "#$ll[4]\t$ll[6]\t$mark\tnot_locate\n";
		if($key_gf{$ll[4]}){$cycle++;goto (CY);}
#	$cycle++;goto (CY);
    }else{
		print STDERR "#$ll[4]\t$ll[6]\t$mark\tlocate\n";
    }
    print STDERR "\n";
}
close IN;

###output
print "#focus_patho\tmethod\tdetect_gf\tgf_rn\tdetect_gt\tgt_rn(specific|ARG-like)\tcopy_num\tmodel_type\tVaration\tgenome_coverage(%)\tAvgDepth\tspe_rn\tgenus_rn\ttotal_Bac_rn\n";
for my $spe(sort keys %Patho_args){
    $opt{pathogen} && $opt{pathogen} ne $spe && next;
    my @lines = split /\n/,$Patho_args{$spe};
    for my $line(@lines){
	print "$line\t$spe2genus_cov_rn{$spe}\t$total_bac_rn{Bacteria}\n";
    }
}

