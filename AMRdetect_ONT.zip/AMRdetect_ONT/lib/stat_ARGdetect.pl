#!usr/bin/perl -w
use strict;
use Getopt::Long;
my %opt = ();
#GetOptions(\%opt,"best_hit");

@ARGV || die "perl $0 <anno.xls> <stat.xls> <reads.anno.lca> <reads.anno.lca.exact> 2>log\n";
my ($anno,$statf,$lcaf,$lcaf_exact) = @ARGV;
###reads序列的lca注释与统计
open IN,$anno || die $!;
my (%arg_cover,%arg_len,%arg_name,%L1_L2,%L1_L3,%anno_info,%lingage,%hit_n_all,%hit_n_all_exact,$reads_lca_anno,$reads_lca_anno2);
my ($lastid,$lastfull,$lastanno,$lastid2,$lastfull2,$lastanno2) = ('','','','','','','','');
while(<IN>){
    chomp;
    my @ll = split /\t/;
    $ll[15] || next;
    my $sub_end_yes =  ($ll[8]==0 || $ll[9]==$ll[7]) ? 1 : 0;
    for my $pos($ll[8]+1 .. $ll[9]){$arg_cover{$ll[6]}{$pos}++;}
    $arg_len{$ll[6]} = $ll[7]; #
    my @ranks = split /;/,$ll[15];
    $arg_name{$ll[6]} = $ranks[-1]; #
    $L1_L2{$ranks[-1]} = $ranks[-2];
    $L1_L3{$ranks[-1]} = $ranks[-3];
    $anno_info{$ranks[-1]} = join "\t",@ll[16..$#ll];  #添加anno
    $lingage{$ranks[-5]}{$ranks[-4]}{$ranks[-3]}{$ranks[-2]}{$ranks[-1]}=1;
    $hit_n_all{$ranks[-1]}++; #all-like reads数计数

    ###reads的lca注释
    my ($cid,$fann)= ("$ll[0]\t$ll[2]",$ll[15]);
    if ($lastid eq ''){
        ($lastid,$lastfull) = ($cid,$fann);
    }else{
        if($lastid ne $cid){
            my @full = split /;/,$lastfull;
            $reads_lca_anno .= join("\t",$lastid,$lastfull)."\n";
            ($lastid,$lastfull)= ($cid,$fann);
        }else{
            $lastfull = &min_same_str($lastfull,$fann);
        }
    }

    ###精确匹配：reads的lca注释
    $ll[13] == 0 && ($ll[10] == ($ll[9]-$ll[8]) || $sub_end_yes) || next;
    $hit_n_all_exact{$ranks[-1]}++; #精确匹配的all-like reads数计数
    my ($cid2,$fann2)= ("$ll[0]\t$ll[2]",$ll[15]);
    if ($lastid2 eq ''){
        ($lastid2,$lastfull2) = ($cid2,$fann2);
    }else{
        if($lastid2 ne $cid2){
            my @full = split /;/,$lastfull2;
            $reads_lca_anno2 .= join("\t",$lastid2,$lastfull2)."\n";
            ($lastid2,$lastfull2)= ($cid2,$fann2);
        }else{
            $lastfull2 = &min_same_str($lastfull2,$fann2);
        }
    }

}
$reads_lca_anno .= join("\t",$lastid,$lastfull)."\n";
$reads_lca_anno2 .= join("\t",$lastid2,$lastfull2)."\n";
close IN;
open OUT,">$lcaf" || die $!;
print OUT $reads_lca_anno;
close OUT;
open OUT,">$lcaf_exact" || die $!;
print OUT "###exact blast LCA anno###\n$reads_lca_anno2";
close OUT;

###统计各rank的reads数
my @reads_annos = split /\n/,$reads_lca_anno;
my %hit_n_lca;
for my $line(@reads_annos){
    my @aa = split /\t/,$line;
    my @ranks = split /;/,$aa[2];
    my $n = @ranks;
    for my $i(0..$#ranks){ my $j = $n-$i;$ranks[$i] eq "__" && next;$hit_n_lca{$j}{$ranks[$i]}++; }
}

my @reads_annos2 = split /\n/,$reads_lca_anno2;
my %hit_n_lca_exact;
for my $line2(@reads_annos2){
    $line2 =~ /^#/ && next;
    $line2 =~ /^\s+/ && next;
    my @aa2 = split /\t/,$line2;
    my @ranks2 = split /;/,$aa2[2];
    my $n = @ranks2;
    for my $i2(0..$#ranks2){ my $j2 = $n-$i2;$ranks2[$i2] eq "__" && next;$hit_n_lca_exact{$j2}{$ranks2[$i2]}++; }
}

###计算coverage...
my (%arg_detect_info);
for my $arg_id(sort keys %arg_cover){
    my @POSs= sort {$a<=>$b} keys %{$arg_cover{$arg_id}};
    my $arg_coverlens = @POSs;
    my $arg_coverage = sprintf "%.3f",$arg_coverlens/$arg_len{$arg_id};

    my $total_base_num = 0;
    for my $i(0..$#POSs){$total_base_num += $arg_cover{$arg_id}{$POSs[$i]};}
    my $avgDepth = sprintf "%.2f",$total_base_num/$arg_coverlens;

    my $discrete_blocknum = 1;
    for my $j(1..$#POSs){$POSs[$j] > $POSs[$j-1]+1 && ($discrete_blocknum++);}
    $hit_n_all_exact{$arg_name{$arg_id}} ||= 0;
    $hit_n_lca_exact{1}{$arg_name{$arg_id}} ||= 0;
    $arg_detect_info{$arg_name{$arg_id}} = "$hit_n_all{$arg_name{$arg_id}}\t$hit_n_lca_exact{1}{$arg_name{$arg_id}}\t$hit_n_all_exact{$arg_name{$arg_id}}\t$discrete_blocknum\t$arg_coverlens/$arg_len{$arg_id}\t$arg_coverage\t$avgDepth";
}


###输出耐药基因检出信息
open OUT,">$statf" || die $!;
print OUT "#L5_Mechanism\tL5_rn_lca\tL4_Group\tL4_rn_lca\tL3_Subgroup\tL3_rn_lca\tL2_GeneType\tL2_rn_lca\tL1_GeneST\tL1_rn_lca\tHitRN_all\tHitRN_lca_exact\tHitRN_all_exact\tDiscrete_block_n\tCoverage\tCoverage_ratio\tCoverDepth\tModel_type\ttaxon_name\tEffective_enzyme_inhibitors\tgene_coded\taro_des\tAMR_Gene_Family\tAMR_Gene_Family_des\tAntibiotic\tDrug_Class\tAdjuvant\tEfflux_Component\tEfflux_Regulator\tResistance_Mechanism\tResistance_Mechanism_des\n";
my %focus_level_uniq;
for my $L5 (sort {$hit_n_lca{5}{$b} <=> $hit_n_lca{5}{$a}} keys %{$hit_n_lca{5}}){
    my @L4s = keys %{$lingage{$L5}};
    for (@L4s){$hit_n_lca{4}{$_} ||=0;}
    for my $L4 (sort {$hit_n_lca{4}{$b} <=> $hit_n_lca{4}{$a}} @L4s){
        my @L3s = keys %{$lingage{$L5}{$L4}};
        for (@L3s){$hit_n_lca{3}{$_} ||=0;}
	my @L1s = ();
	for my $L3 (@L3s){
	    my @L2s = keys %{$lingage{$L5}{$L4}{$L3}};
	    for (@L2s){$hit_n_lca{2}{$_} ||=0;}
	    for my $L2(@L2s){
		my @L1s_tmp = keys %{$lingage{$L5}{$L4}{$L3}{$L2}};
		for (@L1s_tmp){ $hit_n_all{$_} || next;push @L1s,$_; }
	    }
	}
        for my $L1 (sort {$hit_n_all{$b} <=> $hit_n_all{$a}} @L1s){
            my ($L2,$L3) = ($L1_L2{$L1},$L1_L3{$L1});
	    $hit_n_lca{1}{$L1} ||= 0;$hit_n_lca{2}{$L2} ||= 0;$hit_n_lca{3}{$L3} ||= 0;$hit_n_lca{4}{$L4} ||= 0;
            if($hit_n_lca{1}{$L1}){
		$focus_level_uniq{4}{$L4}++;$focus_level_uniq{5}{$L5}++;
                print OUT "$L5\t$hit_n_lca{5}{$L5}\t$L4\t$hit_n_lca{4}{$L4}\t$L3\t$hit_n_lca{3}{$L3}\t$L2\t$hit_n_lca{2}{$L2}\t$L1\t$hit_n_lca{1}{$L1}\t$arg_detect_info{$L1}\t$anno_info{$L1}\n";
            }elsif($hit_n_lca{2}{$L2}){
		$focus_level_uniq{4}{$L4}++;$focus_level_uniq{5}{$L5}++;
                $focus_level_uniq{4}{$L4} > 3 && next;
                print OUT "$L5\t$hit_n_lca{5}{$L5}\t$L4\t$hit_n_lca{4}{$L4}\t$L3\t$hit_n_lca{3}{$L3}\t$L2\t$hit_n_lca{2}{$L2}\t$L1\t0\t$arg_detect_info{$L1}\t$anno_info{$L1}\n";
            }elsif($hit_n_lca{3}{$L3}){
		$focus_level_uniq{4}{$L4}++;$focus_level_uniq{5}{$L5}++;
                $focus_level_uniq{4}{$L4} > 3 && next;
                print OUT "$L5\t$hit_n_lca{5}{$L5}\t$L4\t$hit_n_lca{4}{$L4}\t$L3\t$hit_n_lca{3}{$L3}\t$L2\t0\t$L1\t0\t$arg_detect_info{$L1}\t$anno_info{$L1}\n";
            }elsif($hit_n_lca{4}{$L4}){
		$focus_level_uniq{4}{$L4}++;$focus_level_uniq{5}{$L5}++;
                $focus_level_uniq{4}{$L4} > 3 && next;
                print OUT "$L5\t$hit_n_lca{5}{$L5}\t$L4\t$hit_n_lca{4}{$L4}\t$L3\t0\t$L2\t0\t$L1\t0\t$arg_detect_info{$L1}\t$anno_info{$L1}\n";
            }elsif($hit_n_lca{5}{$L5}){
		$focus_level_uniq{5}{$L5}++;
                $focus_level_uniq{5}{$L5} > 3 && next;
                print OUT "$L5\t$hit_n_lca{5}{$L5}\t$L4\t0\t$L3\t0\t$L2\t0\t$L1\t0\t$arg_detect_info{$L1}\t$anno_info{$L1}\n";
            }
        }
    }
}
close OUT;

####################sub function#########################
sub min_same_str {
    my ($s1,$s2) = @_;
    my @a1 = split /;/,$s1;
    my @a2 = split /;/,$s2;
    my $min = @a1 < @a2 ? @a1 : @a2;
    my @same;
    for my $i (0..$min-1) {
        if($a1[$i] ne $a2[$i]){
                push @same,"__";
        }else{
                push @same,$a1[$i];
        }
    }
    my $same_str = join(";",@same);
    $same_str ||= "";
    return $same_str;
}

