#!usr/bin/perl -w
use strict;

my ($var,$ast,$anno,$feature)=@ARGV;

my %gt2gf;
open IN,"/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/ARGdetectV1.0/lib/card_db/card.info.xls";
<IN>;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$gt2gf{$or[9]}=$or[8];
}
close IN;

open IN,$ast;
my $one=<IN>;
chomp $one;
my @title=split /\t/,$one;
my %hash;
while(<IN>){
	chomp;	
	my @or=split /\t/;
	foreach my $i (1..$#or){
		$hash{$title[$i]}{$or[0]}=$or[$i];
	}
}
close IN;

open IN,$feature;
my %key;
while(<IN>){
	chomp;
	my @or=split /\t/;
	$key{$or[0]}{$or[1]}=$or[2];
}
close IN;

open IN,$anno;
my %dgf;
while(<IN>){
	chomp;
	my @or=split /\t/;
	open FF,$or[1];
	while(my $l=<FF>){
		my @arr=split /\t/,$l;
		$dgf{$or[0]}{$gt2gf{$arr[4]}}=1;
	}
	close FF;
}
close IN;

open IN,$var;
my %dvar;
my $tt=<IN>;
chomp $tt;
my @ttt=split /\t/,$tt;
while(<IN>){
	chomp;
	my @or=split /\t/;
	my @aa=split /:/,$or[0];
	foreach my $i (1..$#or){
		$dvar{$ttt[$i]}{$aa[0]}=$or[$i];
	}
}
close IN;

foreach my $s (sort keys %hash){
	foreach my $drug (sort keys %{$hash{$s}}){
		my $fstr;
		my $fscore=0;
		foreach my $genef (sort keys %{$dgf{$s}}){
	#		print $s,"\t",$drug,"\t",$genef,"\n";
			if ($key{$drug}{$genef}){
				$fscore+=$key{$drug}{$genef};
				$fstr.="$genef;";
			}
		}
		
		foreach my $vv (sort keys %{$dvar{$s}}){
			if($key{$drug}{$vv}){
				$fscore+=$key{$drug}{$vv};
				$fstr.="$vv;";
			}
		}
		$fstr||="/";
		my $label=$fscore > 0 ? "R" : "S";
		print "PA\t",$drug,"\t$s\t",$fscore,"\t",$hash{$s}{$drug},"\t",100,"\t",$fstr,"\t",$label,"\n";
	}
}
