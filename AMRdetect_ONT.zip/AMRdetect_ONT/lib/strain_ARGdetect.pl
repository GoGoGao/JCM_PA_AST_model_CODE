#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Getopt::Long;
my %opt=();
GetOptions(\%opt,"pathogen:s");

@ARGV || die "perl $0 <arg.detect> --pathogen <str> >out \n";
$opt{pathogen} ||= "mix";

open IN,$ARGV[0] || die $!;
my %Patho2Drug_class2Args;
while(<IN>){
    /^#/ && next;
    chomp;
    my @ll =split /\t/;
    my @drug_class = split /;/,$ll[25];
    for my $c(@drug_class){
	$Patho2Drug_class2Args{$opt{pathogen}}{$c} .= "$ll[2]($ll[3])--$ll[4]($ll[5])--$ll[6]($ll[7]|1)--A;";
    }
}

print "#focus_patho\tdrug_class\tdetect_ARGs\tgenome_coverage\tAvgDepth\tspe_rn\tgenus_rn\ttotal_Bac_rn\n";
for my $spe(sort keys %Patho2Drug_class2Args){
    for my $drug_class(sort keys %{$Patho2Drug_class2Args{$spe}}){
        $Patho2Drug_class2Args{$spe}{$drug_class} =~ s/;$//;
        print "$spe\t$drug_class\t$Patho2Drug_class2Args{$spe}{$drug_class}\t100\t100\t300000\t300000\t300000\n";
    }
}

