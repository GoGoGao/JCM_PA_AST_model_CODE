#!usr/bin/perl -w
use strict;

my ($in)=@ARGV;

open IN,$in;
while(<IN>){
	chomp;
	if ($_=~/^#/){
		print $_,"\n";
		next;
	}else{
		my @or=split /\t/;
		#1043983-1045314	  #3556427-3559198
		#if(($or[1]>=1043983 and $or[1] <=1045314 ) or ($or[1]>=3556427 and $or[1] <=3559198)){
		#0/0:0:29:29:0.00000000000000
			if ($or[4] ne "." ){
				my @aa=split /:/,$or[-1];
				next if $aa[-1] < 0.05;
				print $_,"\n";
			}
		#}
	}
}
close IN;
