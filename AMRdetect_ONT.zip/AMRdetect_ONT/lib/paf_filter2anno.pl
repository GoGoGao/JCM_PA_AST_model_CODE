#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use FindBin qw($Bin);
use List::Util qw(min max);
my %opt = ();
GetOptions(\%opt,"add_arg_anno:s","identity:s","NM:s","que_coverage:s","sub_coverage:s");
@ARGV==2 || die "Usage:perl $0 <origin.paf> <filter.paf.anno> [--options]
Description: script to filter m8.file and add annotation infomation
Parameters:
    <origin.paf>	input PAF file
    <filter.paf.anno>	output filtered PAF file with or without annotation
    --identity		set identity threshold, by which filter the hits, default is 0.7
    --NM		max mismatch and gap number, default is 0.15*map_len
    --que_coverage	set query coverage threshold, by which filter the hits, default is 0.9
    --sub_coverage	set subject coverage threshold, by which filter the hits, default is 0.4
    --add_arg_anno	set to add arg annotation info

Example: 
    perl $0 <origin.m6> <filter.m6>
    \n";

#======== set default parameters =============
$opt{add_arg_anno} ||= "$Bin/card_db/card.info.xls";
$opt{identity} ||= 85;
$opt{que_coverage} ||= 0; #当测序reads较短时，重要过滤参数
$opt{sub_coverage} ||= 0; #

#======== ARG annotation infomation ==========
my (%ST2lingage,%ID_anno,%ID_ST);
open IN1,$opt{add_arg_anno} || die $!;  #L6 rank info
while(<IN1>){
    chomp;
    next if(/^seq_nucl_id|^#Seq_ID/);
    my @ll = split /\t/;
    $ID_ST{$ll[0]} = $ll[10];
    $ID_anno{$ll[0]} = join("\t",@ll[2,3,11..$#ll]);
    my $lingage = join ";",@ll[5..10];
    $ST2lingage{$ll[10]} = $lingage;
}
close IN1;

#=========== main function ======================
my($input,$output)=@ARGV;
my (%uniq,%uniq2,$out,%region,$num,%scores,%line);
open IN,$input || die $!;
while(<IN>){     #filter
    chomp;
    my @ll = /\t/ ? (split /\t/) : (split /\s+/);
    my ($que_len,$sub_len,$mapped_bases_n,$mapped_all_bases_n) = @ll[1,6,9,10];
    my $que_alnlen = $ll[3] - $ll[2];
    my $sub_alnlen = $ll[8] - $ll[7];
    my $que_cover = $que_alnlen >= $que_len ? 1 : sprintf("%.3f",$que_alnlen/$que_len);
    my $sub_cover = $sub_alnlen >= $sub_len ? 1 : sprintf("%.3f",$sub_alnlen/$sub_len);
    my $identity = sprintf("%.6f",($mapped_bases_n/$mapped_all_bases_n)*100);
    my $NM = $1 if($ll[12]=~/NM:i:(\S+)/);
    my $score = $1 if($ll[14]=~/AS:i:(\S+)/);
    $identity < $opt{identity} && next; #根据比对的identity过滤
    #$NM > 0.15*$mapped_all_bases_n && next; #根据比对的mis和gap总数过滤
    my $que_end_yes = ($ll[2] == 0 || $ll[3] == $ll[1]) ? 1 : 0;
    my $sub_end_yes = (($ll[4] eq "+" && $ll[7] == 0) || ($ll[4] eq "-" && $ll[8] == $ll[6])) ? 1 : 0;
    if($sub_end_yes){ #当query序列比对上sub序列的末端时，应该限制比对上的长度不低于一定值
	my $align_len_cutoff = $que_end_yes ? 0.2*$sub_len : 0.4*$sub_len;
	$sub_alnlen < $align_len_cutoff && next;
    }else{  #当query序列必比对上sub的中间部位时,应该考虑que_coverage或sub_cover
	if($que_len > 500){
	    $sub_cover < $opt{sub_coverage} && next; #query序列较长时，应该限制sub_cover不低于一定值
	}else{
	    ($opt{que_coverage} && $que_cover < $opt{que_coverage}) && next; #query序列较短时，应该限制que_cover不低于一定值
	}
    }

    $uniq{$ll[0]}++;
    $uniq2{"$ll[0]\t$ll[5]"}++;
    my $sub_identity = $mapped_all_bases_n >= $sub_len ? $identity : sprintf "%.8f",$mapped_bases_n/$sub_len;
    my $mark_exact_align = ($identity == 100 && $NM == 0) ? 1 : 0;

    if($uniq{$ll[0]} == 1){
	$num = 1;
	for my $i ($ll[2]+1 .. $ll[3]){
	    $region{$ll[0]}{$num}{$i} = 1;
	}
	$scores{"$ll[0]_R$num"}{$ll[5]} = $ll[9];
	$line{"$ll[0]_R$num"}{$ll[5]} = join("\t",@ll[0,1],"R1",@ll[2..11],$NM,$score);
	next;
    }
    if($uniq{$ll[0]} >= 2){
	my $mark = 1;
	my @nums = sort {$b <=> $a} keys %{$region{$ll[0]}};
	my ($common_len,$com_percent);
	for my $n(@nums){
	    ($common_len,$com_percent) = (0,0);
	    for my $j ($ll[2]+1 .. $ll[3]){
		$region{$ll[0]}{$n}{$j} && ($common_len++);
	    }
	    $com_percent = sprintf "%.3f",$common_len/($ll[3]-$ll[2]);
	    if($com_percent > 0.05){  #表示query的同一个region的多重比对情况。多重复对比的，后续进行先挑选score最高的，然后LCA注释
		$mark = 0;
		last;  #与前面的region比较，只要找到一个多重比对的情况，直接跳出当前循环
	    }
	}
        if ($mark){
	    $num++;
	    for my $j ($ll[2]+1 .. $ll[3]){
	        $region{$ll[0]}{$num}{$j} = 1;
	    }
	    $scores{"$ll[0]_R$num"}{$ll[5]} = $ll[9];
	    $line{"$ll[0]_R$num"}{$ll[5]} = join("\t",@ll[0,1],"R$num",@ll[2..11],$NM,$score);
        }
    }
}
close IN;

###针对每条query序列的比对区块，输出多个hit中score最高的一个，如果最高的同时存在多个也同时保留并输出(用作后续LCA计算)
open OUT,">$output" || die $!;
foreach my $query_region (sort keys %scores){
    my %score_hit;
    foreach my $sub_id (sort keys %{$scores{$query_region}}){
        $score_hit{$scores{$query_region}{$sub_id}} .= "$query_region,$sub_id\t";
    }
    my @scoces = sort {$b<=>$a} keys %score_hit;
    $score_hit{$scoces[0]} =~ s/\t$//;
    my @hits = split /\t/,$score_hit{$scoces[0]};
    for my $hit(@hits){
        my ($query_id,$sub_id) = split /,/,$hit;
        my @lines = split /\n/,$line{$query_id}{$sub_id};
        for (@lines){
            print OUT "$_\t$ST2lingage{$ID_ST{$sub_id}}\t$ID_anno{$sub_id}\n";
        }
    }
}
close OUT;

