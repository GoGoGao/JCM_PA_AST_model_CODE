#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use Cwd qw(abs_path);
use Getopt::Long;
use File::Basename;
use lib "$Bin/lib/";
use PATHWAY;

#============ 默认参数设置 =============
my $mNGSreads;
my %opt=(outdir=>".",shdir=>"./Shell",db_search=>"CARD",step=>123,vf=>"2G",splitn=>1,
    db_cardopt=>" -c -x map-ont -L  --secondary=no ",
    db_vfopt=>" -evalue 1e-5  -num_threads 2 -outfmt \"6 qseqid qlen sseqid slen pident length mismatch gapopen qstart qend sstart send evalue bitscore\"",
    filter_cardopt=>" ",
    filter_vfopt=>"--identity 90 --align_len 18"
);
GetOptions(\%opt,"data_list:s","pathogen:s","list_readsTaxAnno:s","list_DetectTaxon:s","step:i","vf:s","splitn:i","outdir:s","shdir:s","db_search:s","db_cardopt:s","db_vfopt:s","filter_cardopt:s","filter_vfopt:s","notrun","locate","qopts:s","help","PE","mNGSreads"=>\$mNGSreads);

#============ 程序、数据库设置 =============
#保留毒力基因检测接口
my $db_vf = "";
my $db_vf_anno = "";
my $blastx = "";

my $db_CARD = "/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/AnalyseV2/Softs/CARD/minimap2_index/card.merge.minimap2";
my $db_card_anno = "$Bin/lib/card_db/card.info.xls";
my $minimap2 = "/data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Softs/AMRdetect_v1.4_ONT/minimap2";
my $target_spe_ref = "$Bin/lib/target_ref/ref.fa";
my $super_worker = "perl /data/Yixue/gaojianpeng/BTK/Pepline/Commbin/super_worker.pl --cyqt 1 --maxjob 200 --sleept 30";
my $split_fa = "perl $Bin/lib/split_fa.pl";
my $paf_filter2anno = "perl $Bin/lib/paf_filter2anno.pl";
my $stat_ARGdetect = "perl $Bin/lib/stat_ARGdetect.pl";
my $stat_ARGdetect_filter = "perl $Bin/lib/stat_ARGdetect_filter.pl";
my $strain_ARGdetect = "perl $Bin/lib/strain_ARGdetect.pl";
my $predict_arg2spe = "perl $Bin/lib/predict_arg2spe.pl";
my $extract_pathoseq = "perl $Bin/lib/extract_pathoseq.pl";
my $cover_depth = "perl $Bin/lib/cover_depth.pl";
my $patho_ARGdetect = "perl $Bin/lib/patho_ARGdetect.pl";
my $predict_AST = "perl $Bin/lib/predict_AST.pl";
#my $predict_AST = "perl $Bin/lib/predict_AST.gjp.pl";
my $vcftools="$Bin/lib/vcftools/src/cpp/vcftools";
my $bcftools="$Bin/lib/bcftools-1.14/bcftools";
($mNGSreads )&&( $predict_AST .= " --mNGSreads ");
#================ help information ==========================
($opt{data_list} && -s $opt{data_list})|| die "Name: $0
Description: 1) Blast reads to ARG database for detecting ARG and predict AST on key ARGs screened from ARG-BGWAS(Lasso regression method).
Version: 1.0,20210307 by hanpeng,chengfangyuan,gaojianpeng
Version: 2.0,20210727 database update: CARD --> MEGARes v2.1.2
Contact: p.han\@genskey.com,jp.gao\@genskey.com,fy.chen\@genskey.com
Usage: perl $0 --data_list  cleandata.list  --list_readsTaxAnno reads.taxanno.list --list_DetectTaxon detect.taxon.list [options]
Parameters:
  *--data_list		 [file]  list file of clean data as input, must be set. format: samplename\\tpathogen.fa
  --list_readsTaxAnno 	 [file]  set the list file for each sample's reads taxon annotaion
  --list_DetectTaxon	 [file]  set the list file for each sample's detected species
  --pathogen		 [str]	 when WGS ,can set the pathogen name directly

[options for database]
  --db_search       	 [str]   set databases which will be searched, default = CARD
  --db_cardopt       	 [str]   set parameters for batst to CARD
  --db_vfopt        	 [str]   set parameters for batst to VFDB
  --filter_cardopt	 [str]   set parameters to filter the blast result of CARD, default not set
  --filter_vfopt         [str]   set parameters to filter the blast result of VFDB, default is '--identity 90 --align_len 18'

[options for running]
  --qopts                [str]   other qsub options 
  --vf                   [str]   resource for qsub, default is 2G
  --notrun                       just produce shell script, not qsub    
  --locate                       run locate, not qsub  
  --help                         output help information
                        
[other options]
  --outdir               [str]   output directory, default is ./
  --shdir                [str]   output shell directory, default is ./Shell
  --splitn               [num]   the number of the divided seq file, defult is 1
  --step    		 [str]   default is 123
                     	     	     step1: fq2fa
	                   	     step2: blast to ref database
                      		     step3: detected ARG stat and predict AST

Example: 
  perl $0 --data_list Dataclean.total.list --list_readsTaxAnno reads.taxanno.list --list_DetectTaxon detect.taxon.list --notrun
  perl $0 --data_list Dataclean.total.list --pathogen \"Klebsiella pneumoniae\" \n";
$opt{help} && die `pod2text $0`;

#========== 目录、文件路径/SGE调度参数设置 ========
#$opt{qopts} ||= " --qopts=' -V ' ";
for ($opt{outdir},$opt{shdir}){-d $_ || `mkdir -p $_`;$_ = abs_path($_);}
$opt{data_list} = abs_path($opt{data_list});
$opt{qopts} && ($super_worker .= " --qopts '$opt{qopts}' ");
$super_worker .= " --dvf 8G ";

my $samtools="/data/Yixue/gaojianpeng/BTK/Software/Tools/samtools";
###================= main function =================================
#样本的病原检测结果表单文件，以及样本的reads物种注释文件
my (%readstaxf,%bsdf);
if($opt{list_readsTaxAnno}){
    open IN,$opt{list_readsTaxAnno} || die $!;
    while(<IN>){
	s/^\s+//;s/\s+$//;
        my @ll = split /\s+/;
	$readstaxf{$ll[0]} = $ll[1];
    }
    close IN;
}
if($opt{list_DetectTaxon}){
    open IN,$opt{list_DetectTaxon} || die $!;
    while(<IN>){
        s/^\s+//;s/\s+$//;
        my @ll = split /\s+/;
        $bsdf{$ll[0]} = $ll[1];
    }
    close IN;
}

#================= main function =================================
my ($locate_run,$qsub_run);
my $splits = '\n\n';
##step1, convert fq into fa and split it into muti-file
my (@sample,%sample_fa,%falist);
(-s "$opt{outdir}/01.Fa_cut") || system("mkdir -p $opt{outdir}/01.Fa_cut");
if ($opt{data_list} && $opt{step}=~/1/){
    my @line=`less $opt{data_list}`;
    my $sh_step1;
    my $i;
    foreach my $line (@line){
        chomp $line;
	$i++;
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
        my @tmp = split /\s+/,$line;
        my $sample = $tmp[0];
        push @sample, $sample;
	$sample_fa{$sample} = $tmp[1];
        (-s "$opt{outdir}/01.Fa_cut/$sample") || system ("mkdir -p $opt{outdir}/01.Fa_cut/$sample");
	$sh_step1 .= "cd $opt{outdir}/01.Fa_cut/$sample\n$split_fa n $opt{splitn} $tmp[1] $sample\n";
        for my $nn (1..$opt{splitn}){
	    push @{$falist{$sample}},"$opt{outdir}/01.Fa_cut/$sample/$sample\_$nn.fa";
        }
	$i % 1== 0 && ($sh_step1 .= "\n"); #投递任务时，用作分割文件
    }
    & write_file("$opt{shdir}/step1.split_fa.sh",$sh_step1);
    $locate_run .="$super_worker --mutil --maxjob 20 --splits \"$splits\" step1.split_fa.sh\n";
    $qsub_run .= "$super_worker step1.split_fa.sh --resource $opt{vf} --prefix split_fa --splits '$splits'\n";
}

## step2, reads blast to the all specified databaes
my (%blastout_list,%db);
my @dbs  = split( "-", $opt{db_search} ) if $opt{db_search};for (@dbs){$db{$_}=1;}
if($opt{step}=~/2/){
    my $sh_step2;
    foreach my $db (@dbs){
        my $i = 0;
        for my $sample (@sample) {
	    (-s "$opt{outdir}/02.minimap2/$db/$sample") || `mkdir -p $opt{outdir}/02.minimap2/$db/$sample`;
            foreach my $tmp (@{$falist{$sample}}){
		$i++;
                chomp $tmp;
                my ($split_fa,$path,$suffix) = fileparse($tmp,qr{.fa});
		my $ref_db = $db eq "CARD" ? $db_CARD : $db eq "VFDB" ? $db_vf : ();
		my $bsoft = $db eq "CARD" ? $minimap2 : $blastx;
		my $bopts = $db eq "CARD" ? $opt{db_cardopt} : $db eq "VFDB" ? $opt{db_vfopt} : ();
				$sh_step2 .="cd $opt{outdir}/02.minimap2/$db/$sample\nrm -rf *\n";
                $sh_step2 .= "$bsoft $bopts $ref_db $tmp > $opt{outdir}/02.minimap2/$db/$sample/$split_fa.paf\n";
				$sh_step2.="perl -ne '{chomp;if (\$_=~/^\@/){print \$_,\"\\n\";}else{my \@or=split /\\t/;print \$_,\"\\n\" if \$or[2] ne \"\*\";}}' $sample.sam > $sample.filter.sam\n";
				$sh_step2.="$samtools sort $sample.filter.sam > $sample.sorted.bam\n";
				$sh_step2 .="$minimap2 -x sr -a -t 8 --secondary=no -L $target_spe_ref $tmp > $sample.pathogen.sam\n";
				$sh_step2.="perl -ne '{chomp;if (\$_=~/^\@/){print \$_,\"\\n\";}else{my \@or=split /\\t/;print \$_,\"\\n\" if \$or[2] ne \"\*\";}}' $sample.pathogen.sam > $sample.pathogen.filter.sam\n";
				$sh_step2.="$samtools sort $sample.pathogen.filter.sam > $sample.pathogen.filter.sorted.bam\n";
				$sh_step2.="$samtools index $sample.pathogen.filter.sorted.bam\n";
				$sh_step2.="/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/dotnet/dotnet /data/Yixue/gaojianpeng/BTK/Software/VariationCalling/Pisces/Pisces_5.2.5.20/Pisces.dll -bam $sample.pathogen.filter.sorted.bam -g /data/Yixue/gaojianpeng/Projects/AST/Ruijin_Pseudomonas_aeruginosa/Files/refgenome -minbq 1 -minmq 10 -sbfilter 10 -minvq 0 -minvf 0.0005 -c 1 -OutFolder . \n";
				$sh_step2.="perl $Bin/lib/filter.vcf.pl $sample.pathogen.filter.sorted.genome.vcf > $sample.pathogen.filter.sorted.filter.vcf\n";
				$sh_step2.="set java environment\nJAVA_HOME=/data/Yixue/gaojianpeng/BTK/Software/VariationCalling/SnpEff/jdk-12.0.2\nPATH=\$PATH:\$JAVA_HOME/bin\nexport JAVA_HOME PATH\n/data/Yixue/gaojianpeng/BTK/Software/Basic/miniconda3/bin/snpEff ann NC_002516.2 $sample.pathogen.filter.sorted.filter.vcf > $sample.anno.vcf\n";
				$sh_step2 .="perl $Bin/lib/cover_depth.pl $sample.pathogen.sam --prefix $sample\n";
				$sh_step2 .="rm -rf $sample.pathogen.sam\nrm -rf *.bam\nrm -rf *.genome.vcf *.filter.vcf\nrm -rf snpEff* PiscesLogs $tmp\n";
		$i % 1 == 0 && ($sh_step2 .= "\n");
                push @{$blastout_list{$db}{$sample}}, "$opt{outdir}/02.minimap2/$db/$sample/$split_fa.paf";
            }
        }
#	$i % 5 != 0 && ($sh_step2 .= "\n");
    }
    & write_file("$opt{shdir}/step2.blast_$opt{db_search}.sh",$sh_step2);
    $locate_run .= "$super_worker --mutil --maxjob 20 --splits \"$splits\" step2.blast_$opt{db_search}.sh\n";
    $qsub_run .= "$super_worker step2.blast_$opt{db_search}.sh --resource $opt{vf} --prefix $opt{db_search} --splits '$splits' \n";
}

## step3: filter m6file, annotation and obtain profile
if($opt{step}=~/3/){
    my $sh_step3;
    for my $d(sort keys %db){
	my $i=0;
	my $list_anno;
	for my $sample (@sample){
	    (-s "$opt{outdir}/03.Arg2AST/$d/$sample") || system("mkdir -p $opt{outdir}/03.Arg2AST/$d/$sample");
	    $i++;
	    $sh_step3 .= "cd $opt{outdir}/03.Arg2AST/$d/$sample\n";
            my $filteropts = $d eq "CARD" ? $opt{filter_cardopt} : $d eq "VFDB" ? $opt{filter_vfopt} : ();
            my $annoinfo = $d eq "CARD" ? $db_card_anno : $d eq "VFDB" ? $db_vf_anno : ();
	    $sh_step3 .= "$paf_filter2anno $opt{outdir}/02.minimap2/$d/$sample/$sample\_1.paf $sample.paf.filter.anno\n";
		$sh_step3 .= "#perl $Bin/lib/samfilter.pl $sample.paf.filter.anno $opt{outdir}/02.minimap2/$d/$sample/$sample.sorted.bam | $samtools view -bh > $sample.anno.filter.bam\n";
	    $sh_step3 .= "$stat_ARGdetect $sample.paf.filter.anno $sample.stat.xls $sample.reads.anno.lca $sample.reads.anno.lca.exact 2> arg_stat.log\n";
	    $sh_step3 .= "$stat_ARGdetect_filter $sample.stat.xls > $sample.stat.filter.xls\n"; 
	    if($opt{pathogen}){
#		$sh_step3 .= "$strain_ARGdetect $sample.stat.filter.xls --pathogen \"$opt{pathogen}\" > $sample.DrugClass_detectARGs.xls\n";
		$sh_step3 .="perl $Bin/lib/patho_ARGdetect.pl $sample.stat.filter.xls $opt{outdir}/02.minimap2/$d/$sample/$sample.cvgstat --pathogen \"$opt{pathogen}\" --var $opt{outdir}/02.minimap2/CARD/$sample/$sample.anno.vcf > $sample.DrugClass_detectARGs.xls 2>arg_locate.log\n";
		$sh_step3 .= "$predict_AST $sample.DrugClass_detectARGs.xls > $sample.predict.xls\n";
	    }
	    if($opt{list_readsTaxAnno}){
		$sh_step3 .= "$predict_arg2spe $sample.reads.anno.lca $readstaxf{$sample} > $sample.arg2taxon.xls\n";
		$sh_step3 .= "$extract_pathoseq $readstaxf{$sample} $sample_fa{$sample} > $sample\.pathogen.fa\n";
		$sh_step3 .= "$minimap2 -x map-ont -a  -t 8 --secondary=no -L $target_spe_ref $sample\.pathogen.fa > $sample\.sam\n";
		$sh_step3 .= "$cover_depth $sample\.sam --prefix $sample\n";
		if($opt{list_DetectTaxon}){
		    $sh_step3 .= "$patho_ARGdetect $bsdf{$sample} $sample.stat.filter.xls --arg2taxon $sample.arg2taxon.xls --covstat $sample\.cvgstat > $sample.DrugClass_detectARGs.xls 2> arg_locate.log\n";
		    $sh_step3 .= "$predict_AST $sample.DrugClass_detectARGs.xls > $sample.predict.xls  2>detect.log\n";
		}
	    }
		$sh_step3.="rm -rf $opt{outdir}/02.minimap2/$d/$sample/$sample.sorted.bam\n";
#	    $sh_step3 .= "\n";
	    $i % 1 == 0 && ($sh_step3 .= "\n");
	    $list_anno .= "$sample\t$opt{outdir}/03.Arg2AST/$d/$sample/$sample.stat.xls\n";
        }
	& write_file("$opt{outdir}/03.Arg2AST/$d/$d.anno.list",$list_anno);
    }
    & write_file("$opt{shdir}/step3.1.Arg2AST.sh",$sh_step3);
    $locate_run .= "sh step3.1.Arg2AST.sh\n";
    $qsub_run .= "$super_worker step3.1.Arg2AST.sh --resource $opt{vf} --prefix arganno --splits '\\n\\n' \n";
}

# writeshell and run
$opt{locate} ? & write_file("$opt{shdir}/run_ARG_predict.sh","cd $opt{shdir}\n$locate_run\n") : & write_file("$opt{shdir}/run_ARG_predict.sh","cd $opt{shdir}\n$qsub_run\n");
$opt{notrun} || (system"cd $opt{shdir};sh run_ARG_predict.sh");

###=========sub function========
sub write_file(){
    my ($file,$content) = @_;
    open OUT,">$file" || die $!;
    print OUT $content;
    close OUT;
}
