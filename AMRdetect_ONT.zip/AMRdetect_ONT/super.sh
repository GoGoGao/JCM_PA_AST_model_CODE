perl /data/Yixue/gaojianpeng/BTK/Pepline/Commbin/super_worker.pl --prefix run  --cyqt 1 --maxjob 200 --sleept 30 --resource 2G --splits "\n\n"  
